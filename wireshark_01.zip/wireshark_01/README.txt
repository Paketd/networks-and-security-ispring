Скачал файл c1.pcap отсюда https://github.com/markofu/hackeire/blob/master/2011/pcap/c1.pcap

Открыл его, изучил по различным фильтрам