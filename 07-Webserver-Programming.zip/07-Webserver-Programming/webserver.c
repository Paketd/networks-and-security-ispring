// Лабораторная работа №7, веб сервер
// база: GET, отдача файлов, 200 и 404, лог в консоль
// доп кредит: поток на каждое подключение
// запуск: ./webserver [порт] [папка], без аргументов спросит

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <pthread.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>

#define BUF_SIZE 4096

// папка с сайтом, задаётся в main
static const char *doc_root = "www";

struct client {
    int fd;
    char ip[32];
};

// ответ без файла, для ошибок
static void send_status(int fd, int code, const char *reason, const char *body)
{
    char head[512];
    int len = (int)strlen(body);

    snprintf(head, sizeof(head),
             "HTTP/1.1 %d %s\r\n"
             "Content-Type: text/plain\r\n"
             "Content-Length: %d\r\n"
             "Connection: close\r\n"
             "\r\n",
             code, reason, len);

    write(fd, head, strlen(head));
    write(fd, body, len);
}

// отдаёт файл, который уже открыт
static int send_file(int fd, FILE *f)
{
    char head[512];
    char buf[4096];
    long size;
    size_t n;

    fseek(f, 0, SEEK_END);
    size = ftell(f);
    fseek(f, 0, SEEK_SET);

    snprintf(head, sizeof(head),
             "HTTP/1.1 200 OK\r\n"
             "Content-Type: text/html\r\n"
             "Content-Length: %ld\r\n"
             "Connection: close\r\n"
             "\r\n",
             size);

    if (write(fd, head, strlen(head)) <= 0) {
        fclose(f);
        return -1;
    }

    while ((n = fread(buf, 1, sizeof(buf), f)) > 0) {
        if (write(fd, buf, n) <= 0) {
            fclose(f);
            return -1;
        }
    }

    fclose(f);
    return 0;
}

// поток на одного клиента
static void *handle_client(void *arg)
{
    struct client *c = (struct client *)arg;
    int fd = c->fd;
    char ip[32];
    char req[BUF_SIZE];
    char method[16];
    char path[1024];
    char full[2048];
    FILE *f;
    int n;

    snprintf(ip, sizeof(ip), "%s", c->ip);
    free(c);

    // читаем запрос, для GET одного раза хватает
    n = read(fd, req, sizeof(req) - 1);
    if (n <= 0) {
        close(fd);
        return NULL;
    }
    req[n] = '\0';

    // первая строка вида GET /index.html HTTP/1.1
    if (sscanf(req, "%15s %1023s", method, path) != 2) {
        printf("%s -> 400 bad request\n", ip);
        send_status(fd, 400, "Bad Request", "Bad Request\n");
        close(fd);
        return NULL;
    }

    // строку запроса и якорь отрезаем, они нам не нужны
    path[strcspn(path, "?#")] = '\0';

    if (strcmp(method, "GET") != 0) {
        printf("%s %s %s -> 400\n", ip, method, path);
        send_status(fd, 400, "Bad Request", "Only GET is supported\n");
        close(fd);
        return NULL;
    }

    // не даём выйти за пределы папки с сайтом
    if (strstr(path, "..") != NULL) {
        printf("%s %s -> 400 bad path\n", ip, path);
        send_status(fd, 400, "Bad Request", "Bad path\n");
        close(fd);
        return NULL;
    }

    if (strcmp(path, "/") == 0) {
        strcpy(path, "/index.html");
    }

    snprintf(full, sizeof(full), "%s%s", doc_root, path);

    f = fopen(full, "rb");
    if (f == NULL) {
        printf("%s %s -> 404\n", ip, path);
        send_status(fd, 404, "Not Found", "File Not Found\n");
        close(fd);
        return NULL;
    }

    printf("%s %s -> 200 %s\n", ip, path, full);
    send_file(fd, f);

    close(fd);
    return NULL;
}

int main(int argc, char **argv)
{
    char port_buf[32];
    char root_buf[512];
    int port;
    int interactive = (argc < 2);
    int yes = 1;
    int s, fd;
    int rc = 1;
    pthread_t th;
    pthread_attr_t attr;
    struct sockaddr_in addr;
    struct sockaddr_in peer;
    socklen_t peer_len;
    struct client *c;

    setvbuf(stdout, NULL, _IONBF, 0);

    // без параметров спрашиваем в консоли
    if (interactive) {
        printf("Web server (lab 7)\n\n");

        printf("Port [8080]: ");
        if (fgets(port_buf, sizeof(port_buf), stdin) == NULL) {
            port_buf[0] = '\0';
        }
        port_buf[strcspn(port_buf, "\r\n")] = '\0';

        printf("Document root [www]: ");
        if (fgets(root_buf, sizeof(root_buf), stdin) == NULL) {
            root_buf[0] = '\0';
        }
        root_buf[strcspn(root_buf, "\r\n")] = '\0';

        port = (port_buf[0] == '\0') ? 8080 : atoi(port_buf);
        if (root_buf[0] != '\0') {
            doc_root = strdup(root_buf);
        }
    } else {
        port = atoi(argv[1]);
        if (argc > 2) {
            doc_root = argv[2];
        }
    }

    s = socket(AF_INET, SOCK_STREAM, 0);
    if (s < 0) {
        printf("Cannot create socket\n");
        goto done;
    }

    setsockopt(s, SOL_SOCKET, SO_REUSEADDR, &yes, sizeof(yes));

    memset(&addr, 0, sizeof(addr));
    addr.sin_family = AF_INET;
    addr.sin_addr.s_addr = INADDR_ANY;
    addr.sin_port = htons(port);

    if (bind(s, (struct sockaddr *)&addr, sizeof(addr)) < 0) {
        printf("Cannot bind port %d\n", port);
        close(s);
        goto done;
    }

    if (listen(s, 10) < 0) {
        printf("listen failed\n");
        close(s);
        goto done;
    }

    printf("Serving %s on http://localhost:%d\n", doc_root, port);
    printf("Press Ctrl+C to stop\n\n");

    // у потоков маленький стек, иначе на каждого клиента уходит много памяти
    pthread_attr_init(&attr);
    pthread_attr_setstacksize(&attr, 256 * 1024);

    for (;;) {
        peer_len = sizeof(peer);
        fd = accept(s, (struct sockaddr *)&peer, &peer_len);
        if (fd < 0) {
            printf("accept failed\n");
            continue;
        }

        c = malloc(sizeof(*c));
        if (c == NULL) {
            close(fd);
            continue;
        }
        c->fd = fd;
        snprintf(c->ip, sizeof(c->ip), "%s", inet_ntoa(peer.sin_addr));

        if (pthread_create(&th, &attr, handle_client, c) != 0) {
            printf("%s -> cannot create thread\n", c->ip);
            close(fd);
            free(c);
            continue;
        }
        pthread_detach(th);
    }

    close(s);
    rc = 0;

done:
    // при запуске двойным кликом окно не должно закрыться на ошибке
    if (interactive) {
        printf("\nPress Enter to exit...");
        getchar();
    }
    return rc;
}
