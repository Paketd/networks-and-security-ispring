@echo off
rem Запуск веб-сервера. Параметры: порт и папка с файлами.
rem Пример: start_server.bat 8080 www
webserver.exe %*
echo.
echo Server stopped. Press any key to close this window.
pause >nul
