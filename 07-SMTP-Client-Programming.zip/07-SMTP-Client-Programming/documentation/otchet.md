# Лабораторная работа №7. SMTP-клиент

SMTP-клиент на C

Доп. кредит - TLS через OpenSSL, STARTTLS и вход по логину с паролем.
Писал под Yandex, потому что там у меня есть ящик.

## Как работает

Подключается по TCP и ведёт обычный диалог, проверяя код на каждом шаге

220, потом EHLO 250, потом STARTTLS 220 и рукопожатие TLS,
снова EHLO 250,
AUTH LOGIN 334, логин в base64, 334, пароль в base64, 235,
MAIL FROM 250, RCPT TO 250, DATA 354,
тело письма и точка на отдельной строке 250, QUIT 221

Ответ читаю по байту до \r\n и смотрю четвёртый символ:
пробел значит ответ кончился, дефис значит дальше продолжение.
У EHLO он многострочный, без этой проверки разбор ломается

Код ответа беру atoi от начала строки

Письмо с заголовками From, To, Subject, MIME-Version и
Content-Type: text/plain; charset=UTF-8, строки через \r\n

## Про TLS

Режим зависит от порта.

587 это обычный TCP, потом STARTTLS и всё дальше уже по TLS.
Это то, что в задании.

465 это SMTPS, TLS включается сразу после connect.

У моего провайдера 587 закрыт,
поэтому реальную отправку делал через 465,
а код поддерживает оба

Сертификат не проверяю (SSL_VERIFY_NONE), для лабы нормально.

## Отправка

Сервер smtp.yandex.ru:465, TLS 1.3, AUTH LOGIN.

Нужен пароль приложения из настроек ящика, обычный пароль не подойдёт.

Письмо ушло с pakeev.danila@yandex.ru на danila.pakeev@gmail.com

## Сборка и запуск

make

Нужен OpenSSL: libssl-dev в Linux, libssl-devel в Cygwin.
Собирал cc -Wall -Wextra, предупреждений нет.

./smtp_client <сервер> <порт> <логин> <пароль> <кому> ["тема"]

Без параметров программа всё спрашивает сама: сервер, порт, логин, пароль,
получателя и тему, у каждого вопроса значение по умолчанию.
Так запускаю exe двойным кликом

## Проверка

Отправил реальное письмо через smtp.yandex.ru:465.

Сервер принял аутентификацию (235 Authentication successful),
отправителя и получателя,
и ответил 250 2.0.0 Ok: queued.

Письмо дошло до danila.pakeev@gmail.com,
на скриншоте smtp from yandex.png видно его в ящике.

Лог сессии:

Connecting to smtp.yandex.ru:465
Connected
TLS: connected, version TLSv1.3, cipher TLS_AES_256_GCM_SHA384
S: 220 mail-nwsmtp-smtp-production-main-70 Ok 1794758620-e3aeSDBid4Y0
C: EHLO smtp-client.local
S: 250-mail-nwsmtp-smtp-production-main-70
250-STARTTLS
250-AUTH LOGIN PLAIN XOAUTH2
C: AUTH LOGIN
S: 334 VXNlcm5hbWU6
C: cGFrZWV2LmRhbmlsYUB5YW5kZXgucnU=   (base64 of login)
S: 334 UGFzc3dvcmQ6
C: <base64 of password, hidden>
S: 235 2.7.0 Authentication successful.
C: MAIL FROM:<pakeev.danila@yandex.ru>
S: 250 2.1.0 <pakeev.danila@yandex.ru> ok
C: RCPT TO:<danila.pakeev@gmail.com>
S: 250 2.1.5 <danila.pakeev@gmail.com> recipient ok
C: DATA
S: 354 Start mail input, end with <CRLF>.<CRLF>
C: <message body, 269 bytes>
C: .
S: 250 2.0.0 Ok: queued on mail-nwsmtp-smtp-production-main-70
C: QUIT
S: 221 2.0.0 Closing connecton
Message sent successfully

Полный лог рядом: session.txt.
