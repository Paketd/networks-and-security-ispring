@echo off
rem Запуск SMTP-клиента. 
rem Пример: start_smtp.bat smtp.yandex.ru 465 you@yandex.ru app-password friend@mail.ru "Hello"
smtp_client.exe %*
echo.
echo Done. Press any key to close this window.
pause >nul
