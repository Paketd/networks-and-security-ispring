Самое простое: запустить smtp_client.exe двойным кликом. Программа сама
спросит по очереди:

    SMTP server [smtp.yandex.ru]:
    Port [465]:
    Login:
    App password:
    To:
    Subject [Test message]:

[] - дефолтные значения если не вписать

Пароль — это не пароль от почты, а пароль приложения из настроек ящика
(в Яндексе: Настройки -> Безопасность -> Пароли приложений).

Можно и параметрами, тогда ничего не спрашивает:

    smtp_client.exe smtp.yandex.ru 465 pakeev.danila@yandex.ru app-password danila.pakeev@gmail.com "Hello"

Или через bat-файл:

    start_smtp.bat smtp.yandex.ru 465 pakeev.danila@yandex.ru app-password danila.pakeev@gmail.com "Hello"

Про порты:
  465 - TLS сразу (SMTPS), работает у моего провайдера Уфанет
  587 - обычное соединение + STARTTLS