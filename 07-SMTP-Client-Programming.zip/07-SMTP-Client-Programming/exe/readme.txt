smtp_client.exe, рядом нужен cygwin1.dll

Двойной клик, спросит сервер, порт, логин, пароль приложения, кому и тему.
Enter - значение по умолчанию в квадратных скобках. Пароль это не пароль от
почты, а пароль приложения из настроек ящика.

Параметрами:
smtp_client.exe smtp.yandex.ru 465 pakeev.danila@yandex.ru app-password danila.pakeev@gmail.com "Hello"

Порт 465 = TLS сразу, это что у меня работает. 587 = STARTTLS.
