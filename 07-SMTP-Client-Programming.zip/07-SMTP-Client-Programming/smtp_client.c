// Лабораторная работа №7, SMTP клиент
// доп кредит: TLS, STARTTLS и авторизация AUTH LOGIN

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdarg.h>
#include <unistd.h>
#include <errno.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netdb.h>
#include <netinet/in.h>
#include <arpa/inet.h>

#include <openssl/ssl.h>
#include <openssl/err.h>
#include <openssl/evp.h>

static int   sock = -1;
static SSL  *ssl = NULL;
static SSL_CTX *ctx = NULL;

// ввод-вывод

static int conn_read(void *buf, int len)
{
    if (ssl != NULL) {
        return SSL_read(ssl, buf, len);
    }
    return (int)read(sock, buf, len);
}

static int conn_write(const void *buf, int len)
{
    if (ssl != NULL) {
        return SSL_write(ssl, buf, len);
    }
    return (int)write(sock, buf, len);
}

// читает один ответ сервера, если он многострочный, читает до строки с пробелом
// после кода, возвращает сам код
static int read_reply(char *out, int cap)
{
    int len = 0;

    for (;;) {
        char c;
        int n = conn_read(&c, 1);
        if (n <= 0) {
            out[len < cap ? len : cap - 1] = '\0';
            return -1;
        }
        if (len < cap - 1) {
            out[len++] = c;
        }
        if (c == '\n') {
            int start = len - 2;
            while (start > 0 && out[start - 1] != '\n') {
                start--;
            }
            if (len - start >= 5 && out[start + 3] == ' ') {
                break;
            }
        }
    }
    out[len] = '\0';
    return atoi(out);
}

static int expect(int want)
{
    char buf[4096];
    int code = read_reply(buf, sizeof(buf));

    printf("S: %s", buf);
    if (code != want) {
        printf("!! expected %d, got %d\n", want, code);
        return -1;
    }
    return 0;
}

// Отправляет строку команды и проверяет код ответа
static int cmd(const char *line, int want)
{
    char out[2048];
    snprintf(out, sizeof(out), "%s\r\n", line);

    printf("C: %s", out);
    if (conn_write(out, (int)strlen(out)) <= 0) {
        printf("!! send failed\n");
        return -1;
    }
    return expect(want);
}

static void b64(const char *in, char *out)
{
    EVP_EncodeBlock((unsigned char *)out, (const unsigned char *)in, (int)strlen(in));
}

// Авторизация: AUTH LOGIN, логин и пароль в base64
static int auth_login(const char *user, const char *pass)
{
    char enc[512];

    if (cmd("AUTH LOGIN", 334) != 0) {
        return -1;
    }

    b64(user, enc);
    printf("C: %s   (base64 of login)\n", enc);
    char line[600];
    snprintf(line, sizeof(line), "%s\r\n", enc);
    conn_write(line, (int)strlen(line));
    if (expect(334) != 0) {
        return -1;
    }

    b64(pass, enc);
    printf("C: <base64 of password, hidden>\n");
    snprintf(line, sizeof(line), "%s\r\n", enc);
    conn_write(line, (int)strlen(line));
    return expect(235);
}

static int connect_to(const char *host, int port)
{
    struct addrinfo hints, *res, *p;
    char portstr[16];

    snprintf(portstr, sizeof(portstr), "%d", port);
    memset(&hints, 0, sizeof(hints));
    hints.ai_family = AF_UNSPEC;
    hints.ai_socktype = SOCK_STREAM;

    if (getaddrinfo(host, portstr, &hints, &res) != 0) {
        printf("Cannot resolve %s\n", host);
        return -1;
    }

    for (p = res; p != NULL; p = p->ai_next) {
        sock = socket(p->ai_family, p->ai_socktype, p->ai_protocol);
        if (sock < 0) {
            continue;
        }
        if (connect(sock, p->ai_addr, p->ai_addrlen) == 0) {
            break;
        }
        close(sock);
        sock = -1;
    }
    freeaddrinfo(res);

    return (sock < 0) ? -1 : 0;
}

// Поднимаем TLS поверх уже открытого сокета после ответа 220 на STARTTLS
static int start_tls(const char *host)
{
    SSL_library_init();
    SSL_load_error_strings();

    ctx = SSL_CTX_new(TLS_client_method());
    if (ctx == NULL) {
        return -1;
    }
    SSL_CTX_set_min_proto_version(ctx, TLS1_2_VERSION);
    SSL_CTX_set_verify(ctx, SSL_VERIFY_NONE, NULL);

    ssl = SSL_new(ctx);
    SSL_set_fd(ssl, sock);
    SSL_set_tlsext_host_name(ssl, host);

    if (SSL_connect(ssl) != 1) {
        printf("TLS handshake failed\n");
        ERR_print_errors_fp(stderr);
        return -1;
    }

    printf("TLS: connected, version %s, cipher %s\n",
           SSL_get_version(ssl), SSL_get_cipher(ssl));
    return 0;
}

// строка с клавиатуры, пустой ввод оставляет значение по умолчанию
static void ask(const char *prompt, char *buf, int size, const char *def)
{
    printf("%s", prompt);
    if (fgets(buf, size, stdin) == NULL) {
        buf[0] = '\0';
        return;
    }
    buf[strcspn(buf, "\r\n")] = '\0';
    if (buf[0] == '\0' && def != NULL) {
        snprintf(buf, size, "%s", def);
    }
}

int main(int argc, char **argv)
{
    char buf[4096];
    char msg[4096];
    char host_buf[128], port_buf[16], login_buf[256], pass_buf[256];
    char rcpt_buf[256], subj_buf[256];
    const char *host, *login, *pass, *rcpt, *subject;
    int port, rc;
    int interactive = (argc < 6);

    setvbuf(stdout, NULL, _IONBF, 0);

    // без параметров спрашиваем всё в консоли, тогда exe запускается двойным кликом
    if (interactive) {
        printf("SMTP client (lab 7)\n\n");
        ask("SMTP server [smtp.yandex.ru]: ", host_buf, sizeof(host_buf), "smtp.yandex.ru");
        ask("Port [465]: ", port_buf, sizeof(port_buf), "465");
        ask("Login: ", login_buf, sizeof(login_buf), NULL);
        ask("App password: ", pass_buf, sizeof(pass_buf), NULL);
        ask("To: ", rcpt_buf, sizeof(rcpt_buf), NULL);
        ask("Subject [Test message]: ", subj_buf, sizeof(subj_buf), "Test message");
        printf("\n");

        host = host_buf;
        port = atoi(port_buf);
        login = login_buf;
        pass = pass_buf;
        rcpt = rcpt_buf;
        subject = subj_buf;
    } else {
        host = argv[1];
        port = atoi(argv[2]);
        login = argv[3];
        pass = argv[4];
        rcpt = argv[5];
        subject = (argc > 6) ? argv[6] : "Test message";
    }

    rc = 1;

    printf("Connecting to %s:%d\n", host, port);
    if (connect_to(host, port) != 0) {
        printf("Cannot connect to %s:%d\n", host, port);
        goto cleanup;
    }
    printf("Connected\n");

    // На порту 465 TLS включается сразу, без STARTTLS
    // На 587 сначала обычное приветствие, потом STARTTLS
    if (port == 465) {
        if (start_tls(host) != 0) {
            goto cleanup;
        }
        if (expect(220) != 0) {
            goto cleanup;
        }
        if (cmd("EHLO smtp-client.local", 250) != 0) {
            goto cleanup;
        }
    } else {
        // 1. Приветствие сервера
        if (expect(220) != 0) {
            goto cleanup;
        }

        // 2. EHLO
        if (cmd("EHLO smtp-client.local", 250) != 0) {
            goto cleanup;
        }

        // 3. STARTTLS и рукопожатие
        if (cmd("STARTTLS", 220) != 0) {
            goto cleanup;
        }
        if (start_tls(host) != 0) {
            goto cleanup;
        }

        // после TLS надо поздороваться заново
        if (cmd("EHLO smtp-client.local", 250) != 0) {
            goto cleanup;
        }
    }

    // 4. Авторизация
    if (auth_login(login, pass) != 0) {
        goto cleanup;
    }

    // 5. Отправитель и получатель
    snprintf(buf, sizeof(buf), "MAIL FROM:<%s>", login);
    if (cmd(buf, 250) != 0) {
        goto cleanup;
    }
    snprintf(buf, sizeof(buf), "RCPT TO:<%s>", rcpt);
    if (cmd(buf, 250) != 0) {
        goto cleanup;
    }

    // 6. DATA и само письмо
    if (cmd("DATA", 354) != 0) {
        goto cleanup;
    }

    snprintf(msg, sizeof(msg),
             "From: <%s>\r\n"
             "To: <%s>\r\n"
             "Subject: %s\r\n"
             "MIME-Version: 1.0\r\n"
             "Content-Type: text/plain; charset=UTF-8\r\n"
             "Content-Transfer-Encoding: 8bit\r\n"
             "\r\n"
             "Hello! This is a test message from my SMTP client.\r\n"
             "Sent by smtp_client.c (lab 7).\r\n",
             login, rcpt, subject);

    printf("C: <message body, %d bytes>\n", (int)strlen(msg));
    conn_write(msg, (int)strlen(msg));

    // конец письма отдельная точка
    if (cmd(".", 250) != 0) {
        goto cleanup;
    }

    // 7. QUIT
    if (cmd("QUIT", 221) != 0) {
        goto cleanup;
    }

    printf("Message sent successfully\n");
    rc = 0;

cleanup:
    if (ssl != NULL) {
        SSL_shutdown(ssl);
        SSL_free(ssl);
        ssl = NULL;
    }
    if (ctx != NULL) {
        SSL_CTX_free(ctx);
        ctx = NULL;
    }
    if (sock >= 0) {
        close(sock);
        sock = -1;
    }

    // при запуске двойным кликом окно не должно закрыться сразу
    if (interactive) {
        printf("\nPress Enter to exit...");
        getchar();
    }
    return rc;
}
