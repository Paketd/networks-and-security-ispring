// Лабораторная работа №9. DNS резолвер

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <time.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <sys/time.h>
#include <netinet/in.h>
#include <arpa/inet.h>

#define BUF_SIZE 2048
#define MAX_ANS 8
#define CACHE_SIZE 32

// корневые серверы, адреса зашиты, чтобы не спрашивать их у системного резолвера
static const char *root_servers[] = {
    "198.41.0.4",     // a.root-servers.net
    "199.9.14.201",   // b
    "192.33.4.12",    // c
    "199.7.91.13",    // d
    "192.203.230.10", // e
    "192.5.5.241",    // f
};
static int root_count = 6;

static int g_debug = 0;

struct reply {
    int rcode;
    int ttl;
    char ans[MAX_ANS][512];
    int ans_count;
    char ns[4][256];
    int ns_count;
    char glue_name[4][256];
    char glue_ip[4][64];
    int glue_count;
};

struct cache_entry {
    char name[256];
    int qtype;
    char value[1024];
    time_t expires;
};

static struct cache_entry cache[CACHE_SIZE];
static int cache_count = 0;

// типы записей

static int type_from_name(const char *s)
{
    if (strcasecmp(s, "A") == 0) return 1;
    if (strcasecmp(s, "NS") == 0) return 2;
    if (strcasecmp(s, "CNAME") == 0) return 5;
    if (strcasecmp(s, "SOA") == 0) return 6;
    if (strcasecmp(s, "PTR") == 0) return 12;
    if (strcasecmp(s, "MX") == 0) return 15;
    if (strcasecmp(s, "TXT") == 0) return 16;
    if (strcasecmp(s, "AAAA") == 0) return 28;
    if (strcasecmp(s, "DNSKEY") == 0) return 48;
    if (strcasecmp(s, "DS") == 0) return 43;
    if (strcasecmp(s, "DNSSEC") == 0) return 48;
    return 0;
}

static const char *type_to_name(int t)
{
    switch (t) {
    case 1: return "A";
    case 2: return "NS";
    case 5: return "CNAME";
    case 6: return "SOA";
    case 12: return "PTR";
    case 15: return "MX";
    case 16: return "TXT";
    case 28: return "AAAA";
    case 43: return "DS";
    case 48: return "DNSKEY";
    }
    return "TYPE";
}

// кэш

static void cache_clear(void)
{
    cache_count = 0;
}

static const char *cache_get(const char *name, int qtype)
{
    int i;
    time_t now = time(NULL);

    for (i = 0; i < cache_count; i++) {
        if (cache[i].qtype == qtype && strcasecmp(cache[i].name, name) == 0) {
            if (cache[i].expires > now) {
                return cache[i].value;
            }
        }
    }
    return NULL;
}

static void cache_put(const char *name, int qtype, const char *value, int ttl)
{
    int i;

    if (ttl <= 0) {
        return;
    }
    for (i = 0; i < cache_count; i++) {
        if (cache[i].qtype == qtype && strcasecmp(cache[i].name, name) == 0) {
            break;
        }
    }
    if (i == cache_count) {
        if (cache_count == CACHE_SIZE) {
            i = 0;
        } else {
            cache_count++;
        }
    }
    snprintf(cache[i].name, sizeof(cache[i].name), "%s", name);
    cache[i].qtype = qtype;
    snprintf(cache[i].value, sizeof(cache[i].value), "%s", value);
    cache[i].expires = time(NULL) + ttl;
}

static void cache_show(void)
{
    int i;
    time_t now = time(NULL);

    if (cache_count == 0) {
        printf("cache is empty\n");
        return;
    }
    for (i = 0; i < cache_count; i++) {
        int left = (int)(cache[i].expires - now);
        char value[1024];
        int k;

        if (left < 0) {
            left = 0;
        }
        // адресов может быть несколько, в строке кэша показываю их через пробел
        for (k = 0; cache[i].value[k] != '\0' && k < (int)sizeof(value) - 1; k++) {
            value[k] = (cache[i].value[k] == '\n') ? ' ' : cache[i].value[k];
        }
        value[k] = '\0';
        printf("%s %s -> %s (%d sec left)\n",
               cache[i].name, type_to_name(cache[i].qtype), value, left);
    }
}

// сборка запроса

static int build_query(unsigned char *buf, const char *name, int qtype)
{
    int pos = 12;
    const char *p = name;
    unsigned short id = (unsigned short)(time(NULL) ^ getpid());

    memset(buf, 0, 512);
    buf[0] = id >> 8;
    buf[1] = id & 0xFF;
    buf[2] = 0;          // флаги: обычный запрос, RD не ставим, идём итеративно
    buf[3] = 0;
    buf[4] = 0;
    buf[5] = 1;          // один вопрос

    while (*p != '\0') {
        const char *dot = strchr(p, '.');
        int len = dot ? (int)(dot - p) : (int)strlen(p);

        if (len <= 0 || len > 63) {
            return -1;
        }
        buf[pos++] = (unsigned char)len;
        memcpy(buf + pos, p, len);
        pos += len;
        if (!dot) {
            break;
        }
        p = dot + 1;
    }
    buf[pos++] = 0;

    buf[pos++] = qtype >> 8;
    buf[pos++] = qtype & 0xFF;
    buf[pos++] = 0;
    buf[pos++] = 1;      // класс IN
    return pos;
}

// разбор имён

// читает имя, при необходимости идёт по указателям сжатия
// возвращает позицию сразу после имени в исходном буфере
static int read_name(const unsigned char *msg, int len, int pos, char *out, int outsize)
{
    int next = pos;
    int jumped = 0;
    int o = 0;

    while (pos >= 0 && pos < len) {
        int c = msg[pos];

        if ((c & 0xC0) == 0xC0) {
            if (pos + 1 >= len) {
                return -1;
            }
            if (!jumped) {
                next = pos + 2;
            }
            pos = ((c & 0x3F) << 8) | msg[pos + 1];
            jumped = 1;
            continue;
        }
        if (c == 0) {
            pos++;
            if (!jumped) {
                next = pos;
            }
            break;
        }
        if (pos + 1 + c > len) {
            return -1;
        }
        if (o + c + 2 < outsize) {
            if (o > 0) {
                out[o++] = '.';
            }
            memcpy(out + o, msg + pos + 1, c);
            o += c;
        }
        pos += c + 1;
    }
    if (outsize > 0) {
        out[o] = '\0';
    }
    return next;
}

// разбор ответа

static int format_rdata(const unsigned char *msg, int len, int rdata, int rdlen,
                        int rtype, char *out, int outsize)
{
    char name[256];
    char ip[64];
    int i;

    out[0] = '\0';

    if (rtype == 1 && rdlen == 4) {
        inet_ntop(AF_INET, msg + rdata, ip, sizeof(ip));
        snprintf(out, outsize, "%s", ip);
        return 0;
    }
    if (rtype == 28 && rdlen == 16) {
        inet_ntop(AF_INET6, msg + rdata, ip, sizeof(ip));
        snprintf(out, outsize, "%s", ip);
        return 0;
    }
    if (rtype == 2 || rtype == 5 || rtype == 12) {
        if (read_name(msg, len, rdata, name, sizeof(name)) < 0) {
            return -1;
        }
        snprintf(out, outsize, "%s", name);
        return 0;
    }
    if (rtype == 15 && rdlen > 3) {
        if (read_name(msg, len, rdata + 2, name, sizeof(name)) < 0) {
            return -1;
        }
        snprintf(out, outsize, "%d %s", (msg[rdata] << 8) | msg[rdata + 1], name);
        return 0;
    }
    if (rtype == 16) {
        int pos = 0;
        while (pos < rdlen && (int)strlen(out) < outsize - 2) {
            int slen = msg[rdata + pos];
            if (pos + 1 + slen > rdlen) {
                break;
            }
            strncat(out, (const char *)msg + rdata + pos + 1, slen);
            pos += slen + 1;
        }
        return 0;
    }

    // остальные типы показываю как есть в hex
    for (i = 0; i < rdlen && (int)strlen(out) < outsize - 3; i++) {
        char hex[4];
        snprintf(hex, sizeof(hex), "%02x", msg[rdata + i]);
        strcat(out, hex);
    }
    return 0;
}

static int parse_reply(const unsigned char *msg, int len, int qtype, struct reply *r)
{
    int qd, an, ns, ar;
    int pos = 12;
    int i, total;
    char name[256];

    memset(r, 0, sizeof(*r));

    if (len < 12) {
        return -1;
    }
    r->rcode = msg[3] & 0x0F;
    qd = (msg[4] << 8) | msg[5];
    an = (msg[6] << 8) | msg[7];
    ns = (msg[8] << 8) | msg[9];
    ar = (msg[10] << 8) | msg[11];

    for (i = 0; i < qd; i++) {
        pos = read_name(msg, len, pos, name, sizeof(name));
        if (pos < 0 || pos + 4 > len) {
            return -1;
        }
        pos += 4;
    }

    total = an + ns + ar;
    for (i = 0; i < total; i++) {
        int rtype, rclass, ttl, rdlen, rdata;

        pos = read_name(msg, len, pos, name, sizeof(name));
        if (pos < 0 || pos + 10 > len) {
            return -1;
        }
        rtype = (msg[pos] << 8) | msg[pos + 1];
        rclass = (msg[pos + 2] << 8) | msg[pos + 3];
        ttl = (msg[pos + 4] << 24) | (msg[pos + 5] << 16) | (msg[pos + 6] << 8) | msg[pos + 7];
        rdlen = (msg[pos + 8] << 8) | msg[pos + 9];
        pos += 10;
        rdata = pos;

        if (pos + rdlen > len) {
            return -1;
        }

        if (i < an && rclass == 1) {
            if (rtype == qtype && r->ans_count < MAX_ANS) {
                if (format_rdata(msg, len, rdata, rdlen, rtype,
                                 r->ans[r->ans_count], sizeof(r->ans[0])) == 0) {
                    r->ans_count++;
                    if (r->ttl == 0 || ttl < r->ttl) {
                        r->ttl = ttl;
                    }
                }
            } else if (rtype == 5 && r->ans_count == 0) {
                // для CNAME запоминаем цель в том же массиве, разберёмся в resolve
                char cname[256];
                if (read_name(msg, len, rdata, cname, sizeof(cname)) >= 0) {
                    snprintf(r->ans[0], sizeof(r->ans[0]), "%s", cname);
                    r->ans_count = -1;
                    r->ttl = ttl;
                }
            }
        } else if (i >= an && i < an + ns && rclass == 1 && rtype == 2) {
            if (r->ns_count < 4) {
                read_name(msg, len, rdata, r->ns[r->ns_count], sizeof(r->ns[0]));
                r->ns_count++;
            }
        } else if (i >= an + ns && rclass == 1 && (rtype == 1 || rtype == 28)) {
            if (r->glue_count < 4) {
                char ip[64];
                if (format_rdata(msg, len, rdata, rdlen, rtype, ip, sizeof(ip)) == 0) {
                    snprintf(r->glue_name[r->glue_count], sizeof(r->glue_name[0]), "%s", name);
                    snprintf(r->glue_ip[r->glue_count], sizeof(r->glue_ip[0]), "%s", ip);
                    r->glue_count++;
                }
            }
        }

        pos += rdlen;
    }

    return 0;
}

// сеть

static int udp_query(const char *server, const char *name, int qtype,
                     unsigned char *resp, int respsize)
{
    struct sockaddr_in addr;
    struct timeval tv;
    unsigned char q[512];
    int qlen, n, fd;

    qlen = build_query(q, name, qtype);
    if (qlen < 0) {
        printf("bad domain name\n");
        return -1;
    }

    fd = socket(AF_INET, SOCK_DGRAM, 0);
    if (fd < 0) {
        printf("cannot create socket\n");
        return -1;
    }

    tv.tv_sec = 4;
    tv.tv_usec = 0;
    setsockopt(fd, SOL_SOCKET, SO_RCVTIMEO, &tv, sizeof(tv));

    memset(&addr, 0, sizeof(addr));
    addr.sin_family = AF_INET;
    addr.sin_port = htons(53);
    if (inet_pton(AF_INET, server, &addr.sin_addr) != 1) {
        printf("bad server address %s\n", server);
        close(fd);
        return -1;
    }

    if (g_debug) {
        printf("[debug] asking %s for %s %s\n", server, name, type_to_name(qtype));
    }

    if (sendto(fd, q, qlen, 0, (struct sockaddr *)&addr, sizeof(addr)) < 0) {
        close(fd);
        return -1;
    }

    n = recvfrom(fd, resp, respsize, 0, NULL, NULL);
    close(fd);

    if (n <= 0) {
        if (g_debug) {
            printf("[debug] no answer from %s\n", server);
        }
        return -1;
    }
    return n;
}

// ищет адрес сервера имён среди glue записей
static int pick_ns(const struct reply *r, char *ip, int ipsize)
{
    int i, j;

    for (i = 0; i < r->ns_count; i++) {
        for (j = 0; j < r->glue_count; j++) {
            if (strcasecmp(r->ns[i], r->glue_name[j]) == 0) {
                snprintf(ip, ipsize, "%s", r->glue_ip[j]);
                if (g_debug) {
                    printf("[debug] referral to %s (%s)\n", r->ns[i], ip);
                }
                return 0;
            }
        }
    }
    // glue нет, придётся разрешать имя сервера имён отдельно
    if (r->ns_count > 0) {
        if (g_debug) {
            printf("[debug] no glue for %s, resolving it first\n", r->ns[0]);
        }
        return 1;
    }
    return -1;
}

// основной цикл итеративного разрешения

static int resolve(const char *name, int qtype, char *out, int outsize, int depth)
{
    char cur[256];
    char server[64];
    char ip[64];
    unsigned char resp[BUF_SIZE];
    struct reply r;
    int i, n, step, attempt, restarts;

    if (depth > 3) {
        return -1;
    }
    snprintf(cur, sizeof(cur), "%s", name);
    out[0] = '\0';

    for (restarts = 0; restarts < 5; restarts++) {
        server[0] = '\0';

        // на каждый шаг ищем рабочий корневой сервер только в начале
        for (step = 0; step < 25; step++) {
            if (step == 0) {
                n = -1;
                for (attempt = 0; attempt < root_count; attempt++) {
                    n = udp_query(root_servers[attempt], cur, qtype, resp, sizeof(resp));
                    if (n > 0) {
                        snprintf(server, sizeof(server), "%s", root_servers[attempt]);
                        break;
                    }
                }
                if (n <= 0) {
                    printf("no root server answered\n");
                    return -1;
                }
            } else {
                n = udp_query(server, cur, qtype, resp, sizeof(resp));
                if (n <= 0) {
                    printf("no answer from %s\n", server);
                    return -1;
                }
            }

            if (parse_reply(resp, n, qtype, &r) != 0) {
                printf("bad reply\n");
                return -1;
            }

            if (r.rcode == 3) {
                printf("%s: host not found (NXDOMAIN)\n", cur);
                return -1;
            }
            if (r.rcode != 0) {
                printf("%s: server error, rcode %d\n", cur, r.rcode);
                return -1;
            }

            if (r.ans_count > 0) {
                for (i = 0; i < r.ans_count; i++) {
                    if (out[0] != '\0') {
                        strncat(out, "\n", outsize - strlen(out) - 1);
                    }
                    strncat(out, r.ans[i], outsize - strlen(out) - 1);
                }
                if (g_debug) {
                    printf("[debug] answer from %s, ttl %d\n", server, r.ttl);
                }
                return r.ttl;
            }

            // CNAME без A: идём решать уже новое имя
            if (r.ans_count < 0) {
                if (g_debug) {
                    printf("[debug] cname %s\n", r.ans[0]);
                }
                strncpy(cur, r.ans[0], sizeof(cur) - 1);
                cur[sizeof(cur) - 1] = '\0';
                break;
            }

            i = pick_ns(&r, ip, sizeof(ip));
            if (i < 0) {
                printf("%s: no %s records\n", cur, type_to_name(qtype));
                return -1;
            }
            if (i == 1) {
                char tmp[1024];
                if (resolve(r.ns[0], 1, tmp, sizeof(tmp), depth + 1) <= 0) {
                    printf("%s: cannot resolve ns %s\n", cur, r.ns[0]);
                    return -1;
                }
                tmp[strcspn(tmp, "\n")] = '\0';
                strncpy(ip, tmp, sizeof(ip) - 1);
                ip[sizeof(ip) - 1] = '\0';
            }
            snprintf(server, sizeof(server), "%s", ip);
        }
    }

    return -1;
}

// печатает результат, по одной записи в строке
static void print_lines(const char *text)
{
    const char *p = text;
    const char *nl;

    while (*p != '\0') {
        nl = strchr(p, '\n');
        if (nl == NULL) {
            printf("  %s\n", p);
            break;
        }
        printf("  %.*s\n", (int)(nl - p), p);
        p = nl + 1;
    }
}

static void do_query(const char *name, int qtype)
{
    char value[1024];
    const char *cached;
    int ttl;

    cached = cache_get(name, qtype);
    if (cached != NULL) {
        printf("%s %s (from cache)\n", name, type_to_name(qtype));
        print_lines(cached);
        return;
    }

    ttl = resolve(name, qtype, value, sizeof(value), 0);
    if (ttl < 0) {
        return;
    }
    printf("%s %s\n", name, type_to_name(qtype));
    print_lines(value);
    cache_put(name, qtype, value, ttl);
}

int main(int argc, char **argv)
{
    char name[256] = "";
    char type_buf[32] = "A";
    char line[256];
    const char *name_arg = NULL;
    const char *type_arg = NULL;
    int i, qtype, interactive;

    setvbuf(stdout, NULL, _IONBF, 0);

    for (i = 1; i < argc; i++) {
        if (strcmp(argv[i], "-d") == 0) {
            g_debug = 1;
        } else if (name_arg == NULL) {
            name_arg = argv[i];
        } else if (type_arg == NULL) {
            type_arg = argv[i];
        }
    }

    interactive = (name_arg == NULL);

    if (!interactive) {
        qtype = type_from_name(type_arg ? type_arg : "A");
        if (qtype == 0) {
            printf("unknown record type %s\n", type_arg);
            return 1;
        }
        do_query(name_arg, qtype);
        return 0;
    }

    // интерактивный режим, здесь кэш и имеет смысл
    printf("DNS resolver (lab 9)\n\n");
    printf("Commands: cache - show cache, clear - empty cache, debug - on/off, quit - exit\n\n");

    for (;;) {
        printf("domain> ");
        if (fgets(line, sizeof(line), stdin) == NULL) {
            break;
        }
        line[strcspn(line, "\r\n")] = '\0';

        if (line[0] == '\0') {
            continue;
        }
        if (strcmp(line, "quit") == 0 || strcmp(line, "exit") == 0) {
            break;
        }
        if (strcmp(line, "cache") == 0) {
            cache_show();
            continue;
        }
        if (strcmp(line, "clear") == 0) {
            cache_clear();
            printf("cache cleared\n");
            continue;
        }
        if (strcmp(line, "debug") == 0) {
            g_debug = !g_debug;
            printf("debug is %s\n", g_debug ? "on" : "off");
            continue;
        }

        snprintf(name, sizeof(name), "%s", line);

        printf("type [A]> ");
        if (fgets(type_buf, sizeof(type_buf), stdin) == NULL) {
            break;
        }
        type_buf[strcspn(type_buf, "\r\n")] = '\0';
        if (type_buf[0] == '\0') {
            strcpy(type_buf, "A");
        }

        qtype = type_from_name(type_buf);
        if (qtype == 0) {
            printf("unknown record type %s\n", type_buf);
            continue;
        }
        do_query(name, qtype);
        printf("\n");
    }

    printf("\nPress Enter to exit...");
    getchar();
    return 0;
}
