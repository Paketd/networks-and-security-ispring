@echo off
rem Запуск клиента. Введите число от 1 до 100 и нажмите Enter.
client.exe %*
echo.
echo Done. Press any key to close this window.
pause >nul
