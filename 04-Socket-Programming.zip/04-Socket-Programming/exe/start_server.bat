@echo off
rem Запуск сервера. Окно должно оставаться открытым, пока сервер работает.
server.exe %*
echo.
echo Server stopped. Press any key to close this window.
pause >nul
