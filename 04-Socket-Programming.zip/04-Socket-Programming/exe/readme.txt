client.exe и server.exe требуют файл cygwin1.dll
Как запустить:

1. start_server.bat
2. start_client.bat

Можно и без bat-файлов, из командной строки:

server.exe            (порт по умолчанию 5555)
server.exe 6000      

client.exe            (порт по умолчанию 5555)
client.exe 127.0.0.1 6000
client.exe 127.0.0.1 5555 42     


