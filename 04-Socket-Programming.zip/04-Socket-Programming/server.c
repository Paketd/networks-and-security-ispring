// Лабораторная работа №4, сервер
// конкурентный TCP сервер, на каждого клиента fork (доп кредит)

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <errno.h>
#include <unistd.h>
#include <signal.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <sys/wait.h>
#include <netinet/in.h>
#include <arpa/inet.h>

#define SERVER_NAME  "socket server for lab"
#define SERVER_NUM   50
#define DEFAULT_PORT 5555

static volatile sig_atomic_t stop = 0;

static void on_signal(int signo)
{
    (void)signo;
    stop = 1;
}

// обработка одного клиента, тут уже ребёнок после fork
static void handle_client(int sock)
{
    char buf[256], reply[256], client_name[128];
    int client_num;

    ssize_t n = recv(sock, buf, sizeof(buf) - 1, 0);
    if (n <= 0) {
        printf("Client sent nothing\n");
        return;
    }
    buf[n] = '\0';
    buf[strcspn(buf, "\r\n")] = '\0';
    printf("Received: \"%s\"\n", buf);

    if (sscanf(buf, "%127[^|]|%d", client_name, &client_num) != 2) {
        printf("Wrong message format\n");
        return;
    }

    printf("Client name:   %s\n", client_name);
    printf("Server name:   %s\n", SERVER_NAME);
    printf("Client number: %d\n", client_num);
    printf("Server number: %d\n", SERVER_NUM);
    printf("Sum:           %d\n", client_num + SERVER_NUM);

    // число не из диапазона, по заданию это остановка всего сервера
    if (client_num < 1 || client_num > 100) {
        printf("Number is out of range, stopping server\n");
        kill(getppid(), SIGTERM);
        return;
    }

    snprintf(reply, sizeof(reply), "%s|%d\n", SERVER_NAME, SERVER_NUM);
    if (send(sock, reply, strlen(reply), 0) < 0) {
        perror("send");
    } else {
        printf("Reply sent\n");
    }
}

int main(int argc, char **argv)
{
    int port = (argc > 1) ? atoi(argv[1]) : DEFAULT_PORT;
    int server_sock, client_sock, yes = 1;
    struct sockaddr_in addr, client_addr;
    socklen_t client_len;
    struct sigaction sa;
    pid_t pid;

    // без этого после fork вывод дублируется, потому что буфер копируется в оба процесса
    setvbuf(stdout, NULL, _IONBF, 0);

    server_sock = socket(AF_INET, SOCK_STREAM, 0);
    if (server_sock < 0) {
        perror("socket");
        return 1;
    }
    setsockopt(server_sock, SOL_SOCKET, SO_REUSEADDR, &yes, sizeof(yes));

    memset(&addr, 0, sizeof(addr));
    addr.sin_family = AF_INET;
    addr.sin_port = htons((unsigned short)port);
    addr.sin_addr.s_addr = htonl(INADDR_ANY);

    if (bind(server_sock, (struct sockaddr *)&addr, sizeof(addr)) < 0) {
        perror("bind");
        close(server_sock);
        return 1;
    }
    if (listen(server_sock, 16) < 0) {
        perror("listen");
        close(server_sock);
        return 1;
    }

    // SA_RESTART не ставим, иначе accept не прервётся сигналом
    memset(&sa, 0, sizeof(sa));
    sa.sa_handler = on_signal;
    sigemptyset(&sa.sa_mask);
    sigaction(SIGINT, &sa, NULL);
    sigaction(SIGTERM, &sa, NULL);
    signal(SIGPIPE, SIG_IGN);

    printf("Server \"%s\" is listening on port %d, my number is %d\n",
           SERVER_NAME, port, SERVER_NUM);

    while (!stop) {
        client_len = sizeof(client_addr);
        client_sock = accept(server_sock, (struct sockaddr *)&client_addr, &client_len);
        if (client_sock < 0) {
            if (errno == EINTR) {
                continue;   // пришёл сигнал, цикл сам проверит stop
            }
            perror("accept");
            break;
        }
        printf("Client connected\n");

        pid = fork();
        if (pid == 0) {
            close(server_sock);          // ребёнку listen-сокет не нужен
            printf("Child process %d handles the client\n", (int)getpid());
            handle_client(client_sock);
            close(client_sock);
            _exit(0);                    // именно _exit, чтобы не сбросить чужой буфер
        }
        if (pid < 0) {
            perror("fork");
        }
        close(client_sock);              // родитель соединение не держит
        waitpid(-1, NULL, WNOHANG);      // забираем уже завершившихся детей
    }

    close(server_sock);
    while (waitpid(-1, NULL, 0) > 0) {
        // ждём оставшихся детей
    }
    printf("Server stopped\n");
    return 0;
}
