// Лабораторная работа №4, клиент
// подключается к серверу, отправляет имя и число, печатает ответ и сумму

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>

#define CLIENT_NAME  "Client of Danila Pakeev"
#define DEFAULT_IP   "127.0.0.1"
#define DEFAULT_PORT 5555

int main(int argc, char **argv)
{
    const char *ip = (argc > 1) ? argv[1] : DEFAULT_IP;
    int port = (argc > 2) ? atoi(argv[2]) : DEFAULT_PORT;
    char msg[256], buf[256], server_name[128];
    int my_num, server_num, sock;
    struct sockaddr_in addr;

    printf("My name: %s\n", CLIENT_NAME);

    if (argc > 3) {
        // число дали аргументом, так мне удобнее проверять остановку сервера
        my_num = atoi(argv[3]);
    } else {
        for (;;) {
            printf("Enter a number from 1 to 100: ");
            if (scanf("%d", &my_num) != 1) {
                printf("It's not a number\n");
                while (getchar() != '\n') {
                    // дочитываю строку, иначе она останется во вводе
                }
                continue;
            }
            if (my_num < 1 || my_num > 100) {
                printf("Number must be from 1 to 100\n");
                continue;
            }
            break;
        }
    }

    sock = socket(AF_INET, SOCK_STREAM, 0);
    if (sock < 0) {
        perror("socket");
        return 1;
    }

    memset(&addr, 0, sizeof(addr));
    addr.sin_family = AF_INET;
    addr.sin_port = htons((unsigned short)port);
    if (inet_pton(AF_INET, ip, &addr.sin_addr) != 1) {
        printf("Bad address: %s\n", ip);
        close(sock);
        return 1;
    }
    if (connect(sock, (struct sockaddr *)&addr, sizeof(addr)) < 0) {
        perror("connect");
        close(sock);
        return 1;
    }
    printf("Connected to %s:%d\n", ip, port);

    snprintf(msg, sizeof(msg), "%s|%d\n", CLIENT_NAME, my_num);
    if (send(sock, msg, strlen(msg), 0) < 0) {
        perror("send");
        close(sock);
        return 1;
    }
    printf("Sent: %s", msg);

    // ответ маленький, одного recv хватает
    ssize_t n = recv(sock, buf, sizeof(buf) - 1, 0);
    if (n <= 0) {
        printf("Server closed connection without reply\n");
        close(sock);
        return 1;
    }
    buf[n] = '\0';
    buf[strcspn(buf, "\r\n")] = '\0';
    printf("Got reply: %s\n", buf);

    if (sscanf(buf, "%127[^|]|%d", server_name, &server_num) != 2) {
        printf("Wrong reply format\n");
        close(sock);
        return 1;
    }

    printf("\nMy name:       %s\n", CLIENT_NAME);
    printf("Server name:   %s\n", server_name);
    printf("My number:     %d\n", my_num);
    printf("Server number: %d\n", server_num);
    printf("Sum:           %d\n", my_num + server_num);

    close(sock);
    return 0;
}
