# Лабораторная работа №4. Сокеты

Клиент и сервер на C, TCP.

Доп. кредит - конкурентный сервер через fork.

## Формат сообщений

Текстовый, чтобы читать в логе:

клиент - сервер: имя|число
сервер - клиент: имя|число

Разделитель |, потому что в имени есть пробелы.
Разбираю sscanf с "%[^|]|%d".

Число от 1 до 100

## Клиент

Спрашивает число в цикле.
Буквы и неверный диапазон отвергает и просит заново.

Подключается к 127.0.0.1:5555 (адрес и порт можно аргументами),
шлёт Client of Danila Pakeev|42,
ждёт ответ, печатает оба имени, оба числа и сумму,
закрывает сокет

Число можно дать третьим аргументом, тогда не спрашивает
Нужно, чтобы проверять остановку сервера, не вводя 150 руками:

./client 127.0.0.1 5555 150

## Сервер

socket, bind на 5555 (по заданию больше 5000), listen(16), цикл accept

На клиента fork

Родитель закрывает client_sock и делает waitpid с WNOHANG,
чтобы не копились зомби,
ребёнок обслуживает клиента и выходит через _exit(0).

В начале main стоит setvbuf(stdout, NULL, _IONBF, 0).
После fork буфер копируется в оба процесса,
и без этого вывод дублируется

## Остановка

Число вне 1..100 должно остановить сервер целиком.

Число разбирает ребёнок, а родитель продолжает accept,
поэтому ребёнок шлёт kill(getppid(), SIGTERM).
Родитель ловит сигнал через sigaction, обработчик ставит флаг, цикл выходит.

SA_RESTART не ставлю, иначе accept после сигнала продолжит ждать,
а без него вернёт EINTR.
Ctrl+C работает так же, но через SIGINT.

## Сборка и запуск

make
./server    (первый терминал)
./client    (второй)

gcc с -Wall -Wextra, предупреждений нет.

Аргументы необязательные:
./server, ./server 6000, ./client, ./client 127.0.0.1 5555 42.

Для Windows в exe лежат client.exe, server.exe и cygwin1.dll,
там же bat-файлы для запуска двойным кликом.

## Проверка

Сначала клиенты по одному, потом два сразу.
На скриншотах это есть, один запуск из Cygwin, второй через bat.

Сервер:

Server "socket server for lab" is listening on port 5555, my number is 50
Client connected
Child process 2037 handles the client
Received: "Client of Danila Pakeev|42"
Client number: 42
Server number: 50
Sum:           92
Reply sent
...
Client connected
Client connected
Child process 2042 handles the client
Child process 2043 handles the client
...
Number is out of range, stopping server
Server stopped

Клиент:

My name: Client of Danila Pakeev
Connected to 127.0.0.1:5555
Sent: Client of Danila Pakeev|42
Got reply: socket server for lab|50
Sum:           92

Полные логи рядом: server.txt и client.txt.
