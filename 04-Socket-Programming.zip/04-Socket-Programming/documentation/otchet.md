# Лабораторная работа №4. Сокеты

Сделал клиент и сервер на C, общаются по TCP. Плюс дополнительный кредит -
сервер конкурентный, на каждого клиента делает fork.

## Формат сообщений

Придумал простой текстовый формат, чтобы можно было глазами читать в логе:


клиент - сервер : имя|число
сервер - клиент : имя|число


Разделитель |, потому что имя содержит пробелы. Разбираю через
sscanf(buf, "%[^|]|%d", ...). Число от 1 до 100.

## Клиент (client.c)

Спрашивает число в цикле: если ввели буквы или число не из диапазона — просит
заново. Потом подключается к 127.0.0.1:5555 (адрес и порт можно передать
аргументами), отправляет Client of Danila Pakeev|<число>, ждёт ответ,
разбирает его и печатает оба имени, оба числа и сумму. В конце close().

Если число передать третьим аргументом, клиент не спрашивает его и не проверяет
диапазон — так удобно проверять остановку сервера:


./client 127.0.0.1 5555 150


## Сервер (server.c)

Создаёт сокет, bind на порт 5555 (по заданию больше 5000), listen(16),
дальше бесконечный цикл accept + fork.

После fork родитель закрывает client_sock (иначе соединение никогда не
закроется, потому что дескриптор остаётся открытым) и вызывает
waitpid(-1, NULL, WNOHANG), чтобы не копились зомби. Дальше снова accept.

Ребёнок закрывает listen-сокет (он ему не нужен), обрабатывает клиента,
отправляет ответ и делает _exit(0).

Один момент: после fork stdout дублируется, если буфер ещё не сброшен (буфер
копируется в оба процесса). Поэтому в начале main стоит
setvbuf(stdout, NULL, _IONBF, 0).

Для каждого клиента сервер печатает в лог: имя клиента, имя сервера, число
клиента, число сервера и сумму.

## Остановка сервера

Если клиент прислал число вне 1..100, сервер должен корректно закрыться.
Ребёнок сам сервер не остановит — завершится только он, а родитель продолжит
принимать подключения. Поэтому ребёнок отправляет родителю SIGTERM:
kill(getppid(), SIGTERM).

Родитель ловит сигнал через sigaction (специально без SA_RESTART, иначе
accept не прервётся), accept возвращает EINTR, цикл заканчивается. Дальше
закрывается listen-сокет, waitpid ждёт всех детей, процесс выходит.
Ctrl+C работает так же, только SIGINT.

## Сборка и запуск


make
./server            # терминал 1
./client            # терминал 2

Собирал gcc: cc -Wall -Wextra, предупреждений нет.

Аргументы необязательные, если их не передать — берутся значения по умолчанию
(127.0.0.1 и 5555 у клиента, 5555 у сервера):


./server                  # порт 5555
./server 6000             # другой порт
./client                  # спросит число
./client 127.0.0.1 5555 42


Для Windows в папке exe лежат собранные client.exe и server.exe
(рядом с ними нужен cygwin1.dll), там же bat-файлы для запуска двойным кликом.

## Пример вывода

Сервер (два обычных клиента, потом два одновременно, потом остановка):


Server "socket server for lab" is listening on port 5555, my number is 50
Client connected
Child process 2037 handles the client
Received: "Client of Danila Pakeev|42"
Client name:   Client of Danila Pakeev
Server name:   socket server for lab
Client number: 42
Server number: 50
Sum:           92
Reply sent
...
Client connected
Client connected
Child process 2042 handles the client
Child process 2043 handles the client
Received: "Client of Danila Pakeev|10"
Received: "Client of Danila Pakeev|20"
...
Client connected
Child process 2045 handles the client
Received: "Client of Danila Pakeev|150"
Client number: 150
Sum:           200
Number is out of range, stopping server
Server stopped


Клиент:


My name: Client of Danila Pakeev
Connected to 127.0.0.1:5555
Sent: Client of Danila Pakeev|42
Got reply: socket server for lab|50

My name:       Client of Danila Pakeev
Server name:   socket server for lab
My number:     42
Server number: 50
Sum:           92


Полные логи лежат в demo/server.txt и demo/client.txt.
