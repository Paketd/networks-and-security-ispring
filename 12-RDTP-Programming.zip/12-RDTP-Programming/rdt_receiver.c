// Лабораторная работа №12, RDTP получатель, Go-Back-N
// доп кредит: переменное окно, медленный старт и избегание перегрузок

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <time.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <sys/time.h>
#include <netinet/in.h>
#include <arpa/inet.h>

// окно в пакетах, столько максимум держу данных
#define RECV_WIN 1024
#define MAX_PAYLOAD 1024

static int g_debug = 0;
static int g_loss = 0;      // потери ack, проценты
static int g_delay = 0;     // случайная задержка ack, мс

// заголовок 128 байт, пакет целиком влезает в один MTU
struct pkt_hdr {
    unsigned int magic;
    unsigned int type;
    unsigned int seq;       // байт, с которого начинаются данные
    unsigned int length;    // длина данных
    unsigned int win;       // окно отправителя, пакеты
    unsigned int ack;       // байт, всё до него получено
    unsigned int total;     // размер файла
    unsigned int checksum;
    unsigned int pad[24];
};

#define HDR_SIZE 128
#define PKT_DATA 0
#define PKT_ACK 1
#define PKT_START 2
#define PKT_MAGIC 0x4F544452u

static int sock_fd = -1;
static struct sockaddr_in peer;
static socklen_t peer_len = sizeof(peer);

static unsigned int expect = 0;     // первый ещё не записанный в файл байт
static unsigned int file_size = 0;

static long recv_count = 0;
static long dup_count = 0;
static long bad_checksum = 0;
static long acks_sent = 0;
static long long last_dup_time = 0;

static long long now_ms(void)
{
    struct timespec ts;

    clock_gettime(CLOCK_MONOTONIC, &ts);
    return (long long)ts.tv_sec * 1000 + ts.tv_nsec / 1000000;
}

static void sleep_ms(int ms)
{
    struct timespec ts;

    if (ms <= 0) {
        return;
    }
    ts.tv_sec = ms / 1000;
    ts.tv_nsec = (long)(ms % 1000) * 1000000L;
    nanosleep(&ts, NULL);
}

static unsigned int checksum_of(unsigned char *buf, int len)
{
    unsigned int sum = 0;
    int i;

    for (i = 0; i < len; i += 4) {
        sum += ((unsigned int)buf[i] << 24) | ((unsigned int)buf[i + 1] << 16) |
               ((unsigned int)buf[i + 2] << 8) | buf[i + 3];
    }
    while (sum >> 16) {
        sum = (sum & 0xffff) + (sum >> 16);
    }
    return ~sum;
}

static unsigned int compute_checksum(unsigned char *buf, int len)
{
    struct pkt_hdr *h = (struct pkt_hdr *)buf;
    unsigned int sum;

    h->checksum = 0;
    sum = checksum_of(buf, len);
    h->checksum = sum;
    return sum;
}

// свободное место в буфере получателя, в пакетах
static unsigned int free_window(void)
{
    unsigned int used;

    if (expect >= file_size) {
        return RECV_WIN;
    }
    used = (file_size - expect) / MAX_PAYLOAD;
    if (used >= RECV_WIN) {
        return 1;
    }
    return RECV_WIN - used;
}

static void send_ack(struct pkt_hdr *query)
{
    unsigned char buf[HDR_SIZE];
    struct pkt_hdr *h = (struct pkt_hdr *)buf;

    memset(buf, 0, sizeof(buf));
    h->magic = PKT_MAGIC;
    h->type = PKT_ACK;
    h->ack = expect;
    h->win = free_window();
    h->total = file_size;
    compute_checksum(buf, HDR_SIZE);

    if (g_delay > 0) {
        sleep_ms(rand() % (g_delay + 1));
    }
    if (g_loss > 0 && rand() % 100 < g_loss) {
        if (g_debug) {
            printf("  [drop] ack %u lost in channel simulation\n", expect);
        }
        return;
    }
    sendto(sock_fd, buf, HDR_SIZE, 0, (struct sockaddr *)&peer, peer_len);
    acks_sent++;
    if (g_debug) {
        if (query != NULL) {
            printf("  packet %u, ack %u again, window %u\n", query->seq, expect, free_window());
        } else {
            printf("  ack %u, window %u\n", expect, free_window());
        }
    }
}

static int receive_file(FILE *out)
{
    unsigned char buf[HDR_SIZE + MAX_PAYLOAD];
    struct pkt_hdr *h = (struct pkt_hdr *)buf;
    long long start = now_ms();
    long long last_show = 0;
    int elapsed;

    for (;;) {
        ssize_t n;

        n = recvfrom(sock_fd, buf, sizeof(buf), 0, (struct sockaddr *)&peer, &peer_len);
        if (n < 0) {
            printf("\nno data from sender, giving up\n");
            return (int)(now_ms() - start);
        }
        if (n < HDR_SIZE || h->magic != PKT_MAGIC) {
            continue;
        }
        if (compute_checksum(buf, (int)n) != h->checksum) {
            bad_checksum++;
            if (g_debug) {
                printf("  bad checksum in packet %u, ignored\n", h->seq);
            }
            continue;
        }

        if (h->type == PKT_START) {
            // новый файл, сбрасываю счётчик
            file_size = h->total;
            expect = 0;
            if (g_debug) {
                printf("  start of transfer, file size %u\n", file_size);
            }
            send_ack(NULL);
            continue;
        }
        if (h->type != PKT_DATA) {
            continue;
        }

        recv_count++;
        if (h->seq == expect) {
            // GBN принимает только пакет с ожидаемым номером
            fwrite(buf + HDR_SIZE, 1, h->length, out);
            fflush(out);
            expect += h->length;
            if (g_debug) {
                printf("  recv packet %u, %u bytes\n", h->seq, h->length);
            }
            send_ack(NULL);

            if (file_size > 0 && expect >= file_size) {
                // последний ack мог потеряться, повторяю пару раз
                send_ack(NULL);
                send_ack(NULL);
                break;
            }
        } else {
            // не тот номер, отправитель должен начать окно заново
            if (now_ms() - last_dup_time >= 20) {
                dup_count++;
                last_dup_time = now_ms();
                if (g_debug) {
                    printf("  unexpected packet %u, expected %u\n", h->seq, expect);
                }
                send_ack(h);
            }
        }

        if (now_ms() - last_show > 200) {
            printf("\rprogress %u/%u bytes, space %u packets", expect, file_size, free_window());
            last_show = now_ms() + 1;
        }
    }
    printf("\rprogress %u/%u bytes, space %u packets\n", expect, file_size, free_window());
    elapsed = (int)(now_ms() - start);
    return elapsed;
}

static void print_summary(int elapsed)
{
    printf("\nsummary\n");
    printf("  file size        %u bytes\n", file_size);
    printf("  received         %u bytes\n", expect);
    printf("  time             %d ms\n", elapsed);
    if (elapsed > 0) {
        printf("  throughput       %.1f KB/s\n",
               (double)expect * 1000.0 / elapsed / 1024.0);
    }
    printf("  packets received %ld\n", recv_count);
    printf("  out of order     %ld\n", dup_count);
    printf("  bad checksums    %ld\n", bad_checksum);
    printf("  acks sent        %ld\n", acks_sent);
    printf("  simulated ack loss %d%%\n", g_loss);
}

static int do_recv(int port, const char *path)
{
    struct sockaddr_in addr;
    struct timeval tv;
    FILE *out = NULL;
    int rc = 0;
    int elapsed;

    out = fopen(path, "wb");
    if (out == NULL) {
        printf("cannot create file %s\n", path);
        return 1;
    }

    sock_fd = socket(AF_INET, SOCK_DGRAM, 0);
    if (sock_fd < 0) {
        printf("cannot create socket\n");
        rc = 1;
        goto cleanup;
    }
    memset(&addr, 0, sizeof(addr));
    addr.sin_family = AF_INET;
    addr.sin_addr.s_addr = htonl(INADDR_ANY);
    addr.sin_port = htons((unsigned short)port);
    if (bind(sock_fd, (struct sockaddr *)&addr, sizeof(addr)) < 0) {
        printf("cannot bind to port %d, is it busy?\n", port);
        rc = 1;
        goto cleanup;
    }
    // отправитель молчит 30 секунд, значит его больше нет
    tv.tv_sec = 30;
    tv.tv_usec = 0;
    setsockopt(sock_fd, SOL_SOCKET, SO_RCVTIMEO, &tv, sizeof(tv));

    srand((unsigned int)time(NULL) + 1);
    printf("RDTP receiver, lab 12\n");
    printf("listening on port %d, saving to %s\n", port, path);
    printf("algorithm: Go-Back-N, ack loss %d%%, delay %d ms\n\n", g_loss, g_delay);

    elapsed = receive_file(out);
    if (file_size == 0 || expect < file_size) {
        printf("\ntransfer did not finish, got %u of %u bytes\n", expect, file_size);
        rc = 1;
    }
    print_summary(elapsed);
    printf("\nsaved to %s\n", path);

cleanup:
    if (out != NULL) {
        fclose(out);
    }
    if (sock_fd >= 0) {
        close(sock_fd);
        sock_fd = -1;
    }
    return rc;
}

static void ask(const char *prompt, const char *def, char *buf, int size)
{
    char *p;

    printf("%s [%s]: ", prompt, def);
    fflush(stdout);
    if (fgets(buf, size, stdin) == NULL) {
        snprintf(buf, size, "%s", def);
        return;
    }
    buf[strcspn(buf, "\r\n")] = '\0';
    p = buf;
    while (*p == ' ' || *p == '\t') {
        p++;
    }
    if (*p == '\0') {
        snprintf(buf, size, "%s", def);
    } else if (p != buf) {
        memmove(buf, p, strlen(p) + 1);
    }
}

static void pause_exit(int rc)
{
    printf("\nPress Enter to exit...");
    (void)getchar();
    exit(rc);
}

int main(int argc, char **argv)
{
    char path[512] = "";
    char num[32];
    int port = 0;
    int have_args = 0;
    int i;
    int rc;

    setvbuf(stdout, NULL, _IONBF, 0);

    for (i = 1; i < argc; i++) {
        if (strcmp(argv[i], "-d") == 0) {
            g_debug = 1;
        } else if (strcmp(argv[i], "-l") == 0 && i + 1 < argc) {
            g_loss = atoi(argv[++i]);
        } else if (strcmp(argv[i], "-delay") == 0 && i + 1 < argc) {
            g_delay = atoi(argv[++i]);
        } else if (port == 0 && argv[i][0] != '-') {
            port = atoi(argv[i]);
            have_args = 1;
        } else if (path[0] == '\0' && argv[i][0] != '-') {
            snprintf(path, sizeof(path), "%s", argv[i]);
        }
    }

    if (!have_args) {
        if (argc > 1) {
            printf("usage: rdt_receiver <port> [file] [-l ack_loss%%] [-delay ms] [-d]\n");
            pause_exit(1);
        }
        // запуск двойным кликом, параметры спрашиваем в консоли
        printf("RDTP receiver (lab 12)\n\n");
        ask("Port to listen", "9000", num, sizeof(num));
        port = atoi(num);
        ask("Save received file as", "received.bin", path, sizeof(path));
        ask("Simulated ack loss, percent", "10", num, sizeof(num));
        g_loss = atoi(num);
        ask("Extra ack delay, ms", "5", num, sizeof(num));
        g_delay = atoi(num);
        ask("Debug output on, 1 or 0", "0", num, sizeof(num));
        g_debug = atoi(num);
    }
    if (path[0] == '\0') {
        snprintf(path, sizeof(path), "received.bin");
    }
    if (g_loss < 0) {
        g_loss = 0;
    }
    if (g_loss > 90) {
        g_loss = 90;
    }
    if (g_delay < 0) {
        g_delay = 0;
    }

    rc = do_recv(port, path);
    if (argc < 2 || rc != 0) {
        pause_exit(rc);
    }
    return rc;
}
