// Лабораторная работа №12, RDTP отправитель, Go-Back-N
// доп кредит: переменное окно, медленный старт и избегание перегрузок

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <fcntl.h>
#include <time.h>
#include <netdb.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <sys/time.h>
#include <netinet/in.h>
#include <arpa/inet.h>

// окно считается в пакетах
#define MAX_WIN 256
#define MIN_CWND 2
#define INIT_CWND 2
#define INIT_SSTHRESH 32
#define MAX_PAYLOAD 1024
#define MAX_WINLOG 2000

static int g_debug = 0;
static int g_loss = 10;     // симулируемые потери данных и ack, проценты
static int g_delay = 5;     // дополнительная случайная задержка, мс

// заголовок 128 байт, пакет целиком влезает в один MTU
struct pkt_hdr {
    unsigned int magic;
    unsigned int type;
    unsigned int seq;       // байт, с которого начинаются данные
    unsigned int length;    // длина данных
    unsigned int win;       // окно отправителя, пакеты
    unsigned int ack;       // байт, всё до него получено
    unsigned int total;     // размер файла
    unsigned int checksum;
    unsigned int pad[24];
};

#define HDR_SIZE 128
#define PKT_DATA 0
#define PKT_ACK 1
#define PKT_START 2
#define PKT_MAGIC 0x4F544452u

static int sock_fd = -1;
static struct sockaddr_in dest;
static FILE *fp = NULL;

static unsigned int file_size = 0;
static unsigned int base = 0;       // начало окна, до этого всё принято
static unsigned int next_seq = 0;   // следующий байт, который надо отправить
static unsigned int acked = 0;      // сколько получатель подтвердил
static unsigned int rwnd = 1;       // свободное окно получателя, пакеты

static unsigned int cwnd = INIT_CWND;
static unsigned int ssthresh = INIT_SSTHRESH;

static long long srtt = 0;
static long long rttvar = 0;
static long long timeout_ms = 100;
static long long base_time = 0;     // срок ожидания ack отсчитывается отсюда
static long long sample_time = 0;   // когда ушли данные базы, для rtt

static long sent_all = 0;
static long retransmits = 0;
static long dup_acks = 0;
static long timeouts = 0;

static long winlog[MAX_WINLOG][3];  // время, окно, сколько не подтверждено
static long winlog_count = 0;

static long long now_ms(void)
{
    struct timespec ts;

    clock_gettime(CLOCK_MONOTONIC, &ts);
    return (long long)ts.tv_sec * 1000 + ts.tv_nsec / 1000000;
}

static void sleep_ms(int ms)
{
    struct timespec ts;

    if (ms <= 0) {
        return;
    }
    ts.tv_sec = ms / 1000;
    ts.tv_nsec = (long)(ms % 1000) * 1000000L;
    nanosleep(&ts, NULL);
}

static unsigned int checksum_of(unsigned char *buf, int len)
{
    unsigned int sum = 0;
    int i;

    for (i = 0; i < len; i += 4) {
        sum += ((unsigned int)buf[i] << 24) | ((unsigned int)buf[i + 1] << 16) |
               ((unsigned int)buf[i + 2] << 8) | buf[i + 3];
    }
    while (sum >> 16) {
        sum = (sum & 0xffff) + (sum >> 16);
    }
    return ~sum;
}

static unsigned int compute_checksum(unsigned char *buf, int len)
{
    struct pkt_hdr *h = (struct pkt_hdr *)buf;
    unsigned int sum;

    h->checksum = 0;
    sum = checksum_of(buf, len);
    h->checksum = sum;
    return sum;
}

static unsigned int window_packets(void)
{
    unsigned int w = cwnd;

    if (w > rwnd) {
        w = rwnd;
    }
    if (w > MAX_WIN) {
        w = MAX_WIN;
    }
    if (w < 1) {
        w = 1;
    }
    return w;
}

static void log_window(void)
{
    if (winlog_count < MAX_WINLOG) {
        winlog[winlog_count][0] = now_ms();
        winlog[winlog_count][1] = (long)window_packets();
        winlog[winlog_count][2] = (long)(next_seq - base);
        winlog_count++;
    }
}

static void update_rtt(long long rtt)
{
    if (rtt <= 0) {
        return;
    }
    if (srtt == 0) {
        srtt = rtt;
        rttvar = rtt / 2;
    } else {
        rttvar = (3 * rttvar + llabs(rtt - srtt)) / 4;
        srtt = (7 * srtt + rtt) / 8;
    }
    // запас побольше, иначе при разбросе задержки сыпятся лишние тайм-ауты
    timeout_ms = srtt + 8 * rttvar + 50;
    if (timeout_ms < 100) {
        timeout_ms = 100;
    }
    if (timeout_ms > 3000) {
        timeout_ms = 3000;
    }
}

// на новом ack окно растёт: сначала вдвое, потом на один пакет
static void on_new_ack(long long rtt)
{
    update_rtt(rtt);
    if (cwnd < ssthresh) {
        cwnd = cwnd * 2;
    } else {
        cwnd = cwnd + 1;
    }
    if (cwnd > MAX_WIN) {
        cwnd = MAX_WIN;
    }
    if (g_debug) {
        printf("  [cwnd] %s, window %u packets, timeout %lld ms\n",
               cwnd < ssthresh ? "slow start" : "avoidance", window_packets(), timeout_ms);
    }
}

static void on_loss(void)
{
    ssthresh = cwnd / 2;
    if (ssthresh < MIN_CWND) {
        ssthresh = MIN_CWND;
    }
    cwnd = MIN_CWND;
    if (g_debug) {
        printf("  [loss] window cut to %u, ssthresh %u\n", cwnd, ssthresh);
    }
}

static void send_packet(unsigned int seq, int again)
{
    unsigned char buf[HDR_SIZE + MAX_PAYLOAD];
    struct pkt_hdr *h = (struct pkt_hdr *)buf;
    int len = (int)(file_size - seq);
    int total;
    int dropped;

    if (len > MAX_PAYLOAD) {
        len = MAX_PAYLOAD;
    }
    memset(buf, 0, sizeof(buf));
    if (fseek(fp, (long)seq, SEEK_SET) != 0) {
        return;
    }
    if ((int)fread(buf + HDR_SIZE, 1, len, fp) != len) {
        return;
    }
    h->magic = PKT_MAGIC;
    h->type = PKT_DATA;
    h->seq = seq;
    h->length = (unsigned int)len;
    h->win = window_packets();
    h->total = file_size;
    total = HDR_SIZE + len;
    compute_checksum(buf, total);

    // симуляция ненадёжного канала
    dropped = (g_loss > 0 && rand() % 100 < g_loss);
    if (dropped) {
        // потерянный пакет уходит с задержкой, будто пропал в сети
        if (g_delay > 0) {
            sleep_ms(rand() % (g_delay + 1));
        }
        if (g_debug) {
            printf("  [drop] packet %u lost in channel simulation\n", seq);
        }
    } else if (sendto(sock_fd, buf, total, 0, (struct sockaddr *)&dest, sizeof(dest)) < 0) {
        printf("sendto failed for packet %u\n", seq);
    }
    sent_all++;
    if (g_debug) {
        printf("  %s packet %u, %d bytes, window %u\n",
               again ? "send again" : "send", seq, len, window_packets());
    }}

// разбираю один пришедший ack, 1 если что-то прочитал
static int read_ack(void){
    unsigned char buf[HDR_SIZE + MAX_PAYLOAD];
    struct pkt_hdr *h = (struct pkt_hdr *)buf;
    ssize_t n;

    n = recvfrom(sock_fd, buf, sizeof(buf), 0, NULL, NULL);
    if (n < HDR_SIZE || h->magic != PKT_MAGIC || h->type != PKT_ACK) {
        return 0;
    }
    if (compute_checksum(buf, HDR_SIZE) != h->checksum) {
        if (g_debug) {
            printf("  bad checksum in ack, ignored\n");
        }
        return 1;
    }
    if (h->win > 0 && h->win < MAX_WIN) {
        rwnd = h->win;
    }

    if (h->ack > base && h->ack <= next_seq) {
        long long rtt = now_ms() - sample_time;
        unsigned int moved = h->ack - base;

        if (g_debug) {
            printf("  ack %u, advances by %u bytes, rtt %lld ms\n", h->ack, moved, rtt);
        }
        base = h->ack;
        acked = h->ack;
        base_time = now_ms();
        sample_time = base_time;
        dup_acks = 0;
        on_new_ack(rtt);
        log_window();
    } else if (h->ack == base) {
        dup_acks++;
        if (g_debug) {
            printf("  duplicate ack %u\n", h->ack);
        }
        // три одинаковых ack: пакет потерян, отправляю окно заново
        if (dup_acks == 3) {
            on_loss();
            retransmits += (long)((next_seq - base) / MAX_PAYLOAD);
            next_seq = base;
            base_time = now_ms();
            sample_time = base_time;
            dup_acks = 0;
            log_window();
        }
    }
    return 1;
}

static int wait_ready(long long until)
{
    struct timeval tv;
    fd_set rfds;
    long long left = until - now_ms();

    if (left <= 0) {
        return 0;
    }
    tv.tv_sec = 0;
    tv.tv_usec = (long)(left * 1000);
    FD_ZERO(&rfds);
    FD_SET(sock_fd, &rfds);
    return select(sock_fd + 1, &rfds, NULL, NULL, &tv) > 0;
}

// говорю получателю размер файла и жду ответа
static void do_handshake(void)
{
    unsigned char buf[HDR_SIZE];
    struct pkt_hdr *h = (struct pkt_hdr *)buf;
    int answer = 0;
    int attempt;

    memset(buf, 0, sizeof(buf));
    h->magic = PKT_MAGIC;
    h->type = PKT_START;
    h->total = file_size;
    compute_checksum(buf, HDR_SIZE);

    for (attempt = 0; attempt < 10 && !answer; attempt++) {
        ssize_t n;

        sendto(sock_fd, buf, HDR_SIZE, 0, (struct sockaddr *)&dest, sizeof(dest));
        if (!wait_ready(now_ms() + 500)) {
            continue;
        }
        n = recvfrom(sock_fd, buf, sizeof(buf), 0, NULL, NULL);
        if (n >= HDR_SIZE && h->magic == PKT_MAGIC) {
            answer = 1;
            if (h->win > 0) {
                rwnd = h->win;
            }
        }
    }
    if (!answer) {
        printf("receiver did not answer the start packet, sending anyway\n");
    } else if (g_debug) {
        printf("  receiver is ready, its free space %u packets\n", rwnd);
    }
}

static int send_file(void)
{
    long long start = now_ms();
    long long last_show = 0;
    unsigned int seq;

    base = 0;
    next_seq = 0;
    acked = 0;
    base_time = now_ms();
    sample_time = base_time;

    while (acked < file_size) {
        unsigned int limit = base + window_packets() * MAX_PAYLOAD;
        int sent_now = 0;

        // доливаю окно новыми пакетами, а то, что уже ушло, повторяю по GBN
        for (seq = next_seq; seq < limit && seq < file_size; seq += MAX_PAYLOAD) {
            send_packet(seq, seq < next_seq);
            sent_now = 1;
        }
        if (seq > file_size) {
            seq = file_size;
        }
        next_seq = seq;
        if (sent_now) {
            sample_time = now_ms();
            base_time = sample_time;
            continue;
        }

        // окно забито, жду ack
        while (now_ms() - base_time < timeout_ms) {
            if (read_ack()) {
                break;
            }
            sleep_ms(1);
        }
        if (acked < next_seq && now_ms() - base_time >= timeout_ms) {
            // тайм-аут, по GBN отправляю окно заново
            timeouts++;
            on_loss();
            retransmits += (long)((next_seq - base) / MAX_PAYLOAD);
            if (g_debug) {
                printf("  timeout on %u, go back to %u, %u packets again\n",
                       next_seq, base, (next_seq - base) / MAX_PAYLOAD);
            }
            next_seq = base;
            base_time = now_ms();
            sample_time = base_time;
            log_window();
        }

        if (now_ms() - last_show > 200) {
            printf("\rprogress %u/%u bytes, window %u packets", acked, file_size, window_packets());
            last_show = now_ms() + 1;
        }
    }
    printf("\rprogress %u/%u bytes, window %u packets\n", acked, file_size, window_packets());
    return (int)(now_ms() - start);
}

static void print_summary(int elapsed)
{
    long i;
    long long t0;

    printf("\nsummary\n");
    printf("  file size        %u bytes\n", file_size);
    printf("  time             %d ms\n", elapsed);
    if (elapsed > 0) {
        printf("  throughput       %.1f KB/s\n",
               (double)file_size * 1000.0 / elapsed / 1024.0);
    }
    printf("  packets sent     %ld\n", sent_all);
    printf("  retransmissions  %ld\n", retransmits);
    printf("  timeouts         %ld\n", timeouts);
    printf("  duplicate acks   %ld\n", dup_acks);
    printf("  simulated loss   %d%%\n", g_loss);
    printf("  final window     %u packets\n", window_packets());

    if (winlog_count == 0) {
        return;
    }
    t0 = winlog[0][0];
    printf("\nwindow over time\n");
    printf("  %8s %8s %10s\n", "ms", "window", "buffered");
    for (i = 0; i < winlog_count; i += 5) {
        printf("  %8ld %8ld %10ld\n", (long)(winlog[i][0] - t0),
               winlog[i][1], winlog[i][2]);
    }
}

static int do_send(const char *host, int port, const char *path)
{
    struct addrinfo hints, *res = NULL;
    char port_str[16];
    int rc = 0;
    int elapsed;

    fp = fopen(path, "rb");
    if (fp == NULL) {
        printf("cannot open file %s\n", path);
        return 1;
    }
    fseek(fp, 0, SEEK_END);
    file_size = (unsigned int)ftell(fp);
    fseek(fp, 0, SEEK_SET);
    if (file_size == 0) {
        printf("file %s is empty\n", path);
        rc = 1;
        goto cleanup;
    }

    sock_fd = socket(AF_INET, SOCK_DGRAM, 0);
    if (sock_fd < 0) {
        printf("cannot create socket\n");
        rc = 1;
        goto cleanup;
    }
    // сокет больше не блокируется: ack забираю неблокирующим recvfrom
    fcntl(sock_fd, F_SETFL, O_NONBLOCK);
    memset(&hints, 0, sizeof(hints));
    hints.ai_family = AF_INET;
    hints.ai_socktype = SOCK_DGRAM;
    snprintf(port_str, sizeof(port_str), "%d", port);
    if (getaddrinfo(host, port_str, &hints, &res) != 0) {
        printf("cannot resolve receiver host %s\n", host);
        rc = 1;
        goto cleanup;
    }
    memcpy(&dest, res->ai_addr, sizeof(dest));
    freeaddrinfo(res);
    res = NULL;

    srand((unsigned int)time(NULL));
    printf("RDTP sender, lab 12\n");
    printf("file %s, %u bytes\n", path, file_size);
    printf("receiver %s:%d\n", host, port);
    printf("algorithm: Go-Back-N, loss %d%%, delay %d ms\n\n", g_loss, g_delay);

    do_handshake();
    elapsed = send_file();
    print_summary(elapsed);

cleanup:
    if (fp != NULL) {
        fclose(fp);
        fp = NULL;
    }
    if (sock_fd >= 0) {
        close(sock_fd);
        sock_fd = -1;
    }
    return rc;
}

static void ask(const char *prompt, const char *def, char *buf, int size)
{
    char *p;

    printf("%s [%s]: ", prompt, def);
    fflush(stdout);
    if (fgets(buf, size, stdin) == NULL) {
        snprintf(buf, size, "%s", def);
        return;
    }
    buf[strcspn(buf, "\r\n")] = '\0';
    p = buf;
    while (*p == ' ' || *p == '\t') {
        p++;
    }
    if (*p == '\0') {
        snprintf(buf, size, "%s", def);
    } else if (p != buf) {
        memmove(buf, p, strlen(p) + 1);
    }
}

static void pause_exit(int rc)
{
    printf("\nPress Enter to exit...");
    (void)getchar();
    exit(rc);
}

int main(int argc, char **argv)
{
    char host[256] = "";
    char path[512] = "";
    char num[32];
    int port = 0;
    int have_host = 0;
    int i;
    int rc;

    setvbuf(stdout, NULL, _IONBF, 0);

    for (i = 1; i < argc; i++) {
        if (strcmp(argv[i], "-d") == 0) {
            g_debug = 1;
        } else if (strcmp(argv[i], "-l") == 0 && i + 1 < argc) {
            g_loss = atoi(argv[++i]);
        } else if (strcmp(argv[i], "-delay") == 0 && i + 1 < argc) {
            g_delay = atoi(argv[++i]);
        } else if (strcmp(argv[i], "-alg") == 0 && i + 1 < argc) {
            if (strcmp(argv[i + 1], "GBN") != 0) {
                printf("this sender supports only GBN, got %s\n", argv[i + 1]);
                pause_exit(1);
            }
            i++;
        } else if (!have_host) {
            snprintf(host, sizeof(host), "%s", argv[i]);
            have_host = 1;
        } else if (port == 0) {
            port = atoi(argv[i]);
        } else if (path[0] == '\0') {
            snprintf(path, sizeof(path), "%s", argv[i]);
        }
    }

    if (!have_host || port == 0 || path[0] == '\0') {
        if (argc > 1) {
            printf("usage: rdt_sender <receiver_host> <receiver_port> <file> [-l loss%%] [-delay ms] [-d]\n");
            pause_exit(1);
        }
        // запуск двойным кликом, параметры спрашиваем в консоли
        printf("RDTP sender (lab 12)\n\n");
        ask("Receiver host", "127.0.0.1", host, sizeof(host));
        ask("Receiver port", "9000", num, sizeof(num));
        port = atoi(num);
        ask("File to send", "file.bin", path, sizeof(path));
        ask("Simulated loss, percent", "10", num, sizeof(num));
        g_loss = atoi(num);
        ask("Extra random delay, ms", "5", num, sizeof(num));
        g_delay = atoi(num);
        ask("Debug output on, 1 or 0", "0", num, sizeof(num));
        g_debug = atoi(num);
    }
    if (g_loss < 0) {
        g_loss = 0;
    }
    if (g_loss > 90) {
        g_loss = 90;
    }
    if (g_delay < 0) {
        g_delay = 0;
    }

    rc = do_send(host, port, path);
    if (argc < 2 || rc != 0) {
        pause_exit(rc);
    }
    return rc;
}
