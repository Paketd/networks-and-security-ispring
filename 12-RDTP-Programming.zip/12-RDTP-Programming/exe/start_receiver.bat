@echo off
rdt_receiver.exe %*
echo.
echo Done. Press any key...
pause >nul
