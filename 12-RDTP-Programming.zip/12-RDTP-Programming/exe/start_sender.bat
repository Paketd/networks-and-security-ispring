@echo off
rdt_sender.exe %*
echo.
echo Done. Press any key...
pause >nul
