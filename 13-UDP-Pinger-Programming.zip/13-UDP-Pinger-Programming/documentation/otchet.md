# Лабораторная работа №13. UDP Pinger

Клиент и сервер по образцу ping.

Доп. кредит - расширенная статистика: минимум, максимум и среднее RTT плюс
процент потерь.

## Как работает

UDP, без соединения

Формат сообщения такой:

Ping <номер> <время в миллисекундах>

Номер от 1 до 10, время беру из gettimeofday прямо перед отправкой

Строка уходит целиком, сервер её печатает и отправляет обратно тем же
пакетом.
Клиент по тексту ответа видит, что это его пакет

RTT считаю по своим часам

Записываю время в микросекундах перед sendto,
потом после recvfrom снова,
разницу делю на 1000 и получаю миллисекунды

На localhost выходит 0.2-0.8 мс

Время из самого пакета для расчёта не беру,
у двух машин разные часы и по нему одностороннюю задержку не посчитать.

В тексте оно просто для наглядности и чтобы сервер его показал.

Тайм-аут через SO_RCVTIMEO, по умолчанию 1000 мс, меняется флагом -t

Если recvfrom вернул ошибку, значит ответа нет,
печатаю Request timed out и иду к следующему номеру

Если сервера нет совсем, все пакеты отвалятся по тайм-ауту,
а программа всё равно покажет статистику

## Сервер

Связывает UDP сокет с портом и отвечает на каждый пакет тем же содержимым,
печатает отправителя, размер и текст

Флаг -c N останавливает его после N пакетов, это удобно чтобы показать потери:
клиент шлёт больше, чем сервер собирался принять

## Сборка и запуск

make

cc с -Wall -Wextra, предупреждений нет, работает и в Linux и в Cygwin.

./udp_pinger_server <port> [-c count] [-d]
./udp_pinger_client <host> <port> [-n count] [-t timeout_ms] [-d]

Без аргументов обе программы спрашивают параметры сами,
так exe запускается двойным кликом.

## Проверка

Сервер и клиент на localhost, 10 пакетов, тайм-аут 1000 мс, все дошли:

UDP pinger, lab 13
pinging 127.0.0.1:12010, 10 packets, timeout 1000 ms

Reply from server: Ping 1 1794805634432, RTT = 0.856 ms
Reply from server: Ping 2 1794805634433, RTT = 0.299 ms
Reply from server: Ping 3 1794805634433, RTT = 0.341 ms
Reply from server: Ping 4 1794805634434, RTT = 0.236 ms
Reply from server: Ping 5 1794805634434, RTT = 0.277 ms
Reply from server: Ping 6 1794805634434, RTT = 0.249 ms
Reply from server: Ping 7 1794805634435, RTT = 0.252 ms
Reply from server: Ping 8 1794805634435, RTT = 0.227 ms
Reply from server: Ping 9 1794805634435, RTT = 0.221 ms
Reply from server: Ping 10 1794805634435, RTT = 0.230 ms

--- ping statistics ---
sent 10, received 10, lost 0 (0%)
rtt min 0.221 ms, max 0.856 ms, avg 0.319 ms

Сервер в это время печатал принятые пакеты:

[1] from 127.0.0.1:60182, 20 bytes: Ping 1 1794805634432
[1] from 127.0.0.1:60182, 20 bytes: Ping 2 1794805634433
...

Потом запустил сервер с -c 6, а клиент на 10 пакетов
Четыре последних ушли в тайм-аут, в статистике виден процент потерь:

UDP pinger, lab 13
pinging 127.0.0.1:12011, 10 packets, timeout 400 ms

Reply from server: Ping 1 1794805637625, RTT = 0.814 ms
Reply from server: Ping 2 1794805637626, RTT = 0.282 ms
Reply from server: Ping 3 1794805637627, RTT = 0.269 ms
Reply from server: Ping 4 1794805637627, RTT = 0.262 ms
Reply from server: Ping 5 1794805637627, RTT = 0.260 ms
Reply from server: Ping 6 1794805637628, RTT = 0.262 ms
Request timed out
Request timed out
Request timed out
Request timed out

--- ping statistics ---
sent 10, received 6, lost 4 (40%)
rtt min 0.260 ms, max 0.814 ms, avg 0.358 ms

И третий случай, сервер вообще не запущен:

UDP pinger, lab 13
pinging 127.0.0.1:12019, 3 packets, timeout 300 ms

Request timed out
Request timed out
Request timed out

--- ping statistics ---
sent 3, received 0, lost 3 (100%)
no replies, rtt is unknown

Логи рядом: server.txt, client.txt, server_loss.txt, client_loss.txt,
client_timeout.txt

Второй доп. кредит с Heartbeat не делал, только статистику

В exe лежат udp_pinger_server.exe и udp_pinger_client.exe с cygwin1.dll,
readme и bat-файлы
