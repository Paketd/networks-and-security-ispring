@echo off
udp_pinger_server.exe %*
echo.
echo Done. Press any key...
pause >nul
