@echo off
udp_pinger_client.exe %*
echo.
echo Done. Press any key...
pause >nul
