// Лабораторная работа №13, UDP pinger, сервер
// принимает ping и отправляет тот же пакет обратно

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <time.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>

#define BUF_SIZE 1024
#define DEFAULT_PORT 12000
#define MAX_COUNT 100000

static int g_debug = 0;

static void pause_exit(int rc)
{
    printf("\nPress Enter to exit...");
    (void)getchar();
    exit(rc);
}

static void ask(const char *prompt, const char *def, char *buf, int size)
{
    char *p;

    printf("%s [%s]: ", prompt, def);
    fflush(stdout);
    if (fgets(buf, size, stdin) == NULL) {
        snprintf(buf, size, "%s", def);
        return;
    }
    buf[strcspn(buf, "\r\n")] = '\0';
    p = buf;
    while (*p == ' ' || *p == '\t') {
        p++;
    }
    if (*p == '\0') {
        snprintf(buf, size, "%s", def);
    } else if (p != buf) {
        memmove(buf, p, strlen(p) + 1);
    }
}

// сервер слушает порт, пока не наберётся count пакетов (или бесконечно)
static int run_server(int port, int count)
{
    struct sockaddr_in addr, peer;
    socklen_t peer_len = sizeof(peer);
    char buf[BUF_SIZE];
    int sock_fd;
    int received = 0;
    long long start, now;

    sock_fd = socket(AF_INET, SOCK_DGRAM, 0);
    if (sock_fd < 0) {
        printf("cannot create socket\n");
        return 1;
    }
    memset(&addr, 0, sizeof(addr));
    addr.sin_family = AF_INET;
    addr.sin_addr.s_addr = htonl(INADDR_ANY);
    addr.sin_port = htons((unsigned short)port);
    if (bind(sock_fd, (struct sockaddr *)&addr, sizeof(addr)) < 0) {
        printf("cannot bind to port %d, is it busy?\n", port);
        close(sock_fd);
        return 1;
    }

    printf("UDP pinger server, lab 13\n");
    printf("listening on port %d, press Ctrl+C to stop\n\n", port);
    start = (long long)time(NULL);

    while (received < count) {
        ssize_t n;
        char from[64];

        n = recvfrom(sock_fd, buf, sizeof(buf) - 1, 0, (struct sockaddr *)&peer, &peer_len);
        if (n < 0) {
            printf("recvfrom failed\n");
            break;
        }
        buf[n] = '\0';
        received++;
        inet_ntop(AF_INET, &peer.sin_addr, from, sizeof(from));
        now = (long long)time(NULL);
        printf("[%lld] from %s:%d, %ld bytes: %s\n", now - start, from,
               ntohs(peer.sin_port), (long)n, buf);
        if (g_debug) {
            printf("  echo back to %s:%d\n", from, ntohs(peer.sin_port));
        }

        // echo: отправляю ровно то, что пришло, чтобы клиент узнал свой номер
        if (sendto(sock_fd, buf, (size_t)n, 0, (struct sockaddr *)&peer, peer_len) < 0) {
            printf("sendto failed for %s\n", from);
        }
    }

    printf("\ntotal %d packets, server stops\n", received);
    close(sock_fd);
    return 0;
}

int main(int argc, char **argv)
{
    char num[32];
    char buf[32];
    int port = 0;
    int count = MAX_COUNT;
    int have_args = 0;
    int i;
    int rc;

    setvbuf(stdout, NULL, _IONBF, 0);

    for (i = 1; i < argc; i++) {
        if (strcmp(argv[i], "-d") == 0) {
            g_debug = 1;
        } else if (strcmp(argv[i], "-c") == 0 && i + 1 < argc) {
            count = atoi(argv[++i]);
            have_args = 1;
        } else if (argv[i][0] != '-') {
            port = atoi(argv[i]);
            have_args = 1;
        }
    }

    if (!have_args) {
        if (argc > 1) {
            printf("usage: udp_pinger_server <port> [-c count] [-d]\n");
            pause_exit(1);
        }
        // запуск двойным кликом, параметры спрашиваем в консоли
        printf("UDP pinger server (lab 13)\n\n");
        snprintf(num, sizeof(num), "%d", DEFAULT_PORT);
        ask("Port to listen", num, buf, sizeof(buf));
        port = atoi(buf);
        ask("Stop after N packets", "100000", num, sizeof(num));
        count = atoi(num);
        ask("Debug output on, 1 or 0", "0", num, sizeof(num));
        g_debug = atoi(num);
    }

    if (port <= 0 || port > 65535) {
        printf("bad port %d\n", port);
        pause_exit(1);
    }
    if (count <= 0) {
        count = MAX_COUNT;
    }

    rc = run_server(port, count);
    if (argc < 2 || rc != 0) {
        pause_exit(rc);
    }
    return rc;
}
