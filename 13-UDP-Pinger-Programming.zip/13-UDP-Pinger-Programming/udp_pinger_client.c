// Лабораторная работа №13, UDP pinger, клиент
// доп кредит: min, max и среднее RTT плюс процент потерь

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <netdb.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <sys/time.h>
#include <netinet/in.h>
#include <arpa/inet.h>

#define BUF_SIZE 1024
#define DEFAULT_PORT 12000
#define DEFAULT_COUNT 10
#define DEFAULT_TIMEOUT_MS 1000

static int g_debug = 0;

// текущее время в миллисекундах и микросекундах, нужно для точного rtt
static void now_time(long long *ms, long long *us)
{
    struct timeval tv;

    gettimeofday(&tv, NULL);
    *ms = (long long)tv.tv_sec * 1000 + tv.tv_usec / 1000;
    *us = (long long)tv.tv_sec * 1000 * 1000 + tv.tv_usec;
}

static void pause_exit(int rc)
{
    printf("\nPress Enter to exit...");
    (void)getchar();
    exit(rc);
}

static void ask(const char *prompt, const char *def, char *buf, int size)
{
    char *p;

    printf("%s [%s]: ", prompt, def);
    fflush(stdout);
    if (fgets(buf, size, stdin) == NULL) {
        snprintf(buf, size, "%s", def);
        return;
    }
    buf[strcspn(buf, "\r\n")] = '\0';
    p = buf;
    while (*p == ' ' || *p == '\t') {
        p++;
    }
    if (*p == '\0') {
        snprintf(buf, size, "%s", def);
    } else if (p != buf) {
        memmove(buf, p, strlen(p) + 1);
    }
}

static void print_stats(long sent, long received, double min_ms, double max_ms,
                        double sum_ms, int count)
{
    double avg = 0.0;

    if (received > 0) {
        avg = sum_ms / count;
    }
    printf("\n--- ping statistics ---\n");
    printf("sent %ld, received %ld, lost %ld (%d%%)\n", sent, received, sent - received,
           sent > 0 ? (int)((sent - received) * 100 / sent) : 0);
    if (received > 0) {
        printf("rtt min %.3f ms, max %.3f ms, avg %.3f ms\n", min_ms, max_ms, avg);
    } else {
        printf("no replies, rtt is unknown\n");
    }
}

static int run_client(const char *host, int port, int count, int timeout_ms)
{
    struct addrinfo hints, *res = NULL;
    struct sockaddr_in dest;
    struct timeval tv;
    char port_str[16];
    char buf[BUF_SIZE];
    char msg[BUF_SIZE];
    int sock_fd;
    int i;
    long received = 0;
    double sum_ms = 0.0;
    double min_ms = 0.0;
    double max_ms = 0.0;

    memset(&hints, 0, sizeof(hints));
    hints.ai_family = AF_INET;
    hints.ai_socktype = SOCK_DGRAM;
    snprintf(port_str, sizeof(port_str), "%d", port);
    if (getaddrinfo(host, port_str, &hints, &res) != 0) {
        printf("cannot resolve host %s\n", host);
        return 1;
    }
    memset(&dest, 0, sizeof(dest));
    memcpy(&dest, res->ai_addr, sizeof(dest));
    freeaddrinfo(res);

    sock_fd = socket(AF_INET, SOCK_DGRAM, 0);
    if (sock_fd < 0) {
        printf("cannot create socket\n");
        return 1;
    }
    // тайм-аут на приём, чтобы recvfrom не висел вечно
    tv.tv_sec = timeout_ms / 1000;
    tv.tv_usec = (timeout_ms % 1000) * 1000;
    setsockopt(sock_fd, SOL_SOCKET, SO_RCVTIMEO, &tv, sizeof(tv));

    printf("UDP pinger, lab 13\n");
    printf("pinging %s:%d, %d packets, timeout %d ms\n\n", host, port, count, timeout_ms);

    for (i = 1; i <= count; i++) {
        long long sent_ms, sent_us, got_ms, got_us;
        double rtt;
        ssize_t n;

        now_time(&sent_ms, &sent_us);
        snprintf(msg, sizeof(msg), "Ping %d %lld", i, sent_ms);
        if (sendto(sock_fd, msg, strlen(msg), 0, (struct sockaddr *)&dest, sizeof(dest)) < 0) {
            printf("sendto failed for ping %d\n", i);
            continue;
        }
        if (g_debug) {
            printf("  sent %s\n", msg);
        }

        n = recvfrom(sock_fd, buf, sizeof(buf) - 1, 0, NULL, NULL);
        now_time(&got_ms, &got_us);
        if (n < 0) {
            printf("Request timed out\n");
            continue;
        }
        buf[n] = '\0';
        rtt = (double)(got_us - sent_us) / 1000.0;
        received++;
        sum_ms += rtt;
        if (received == 1 || rtt < min_ms) {
            min_ms = rtt;
        }
        if (received == 1 || rtt > max_ms) {
            max_ms = rtt;
        }
        if (g_debug) {
            printf("  got %s\n", buf);
        }
        printf("Reply from server: %s, RTT = %.3f ms\n", buf, rtt);
    }

    print_stats(count, received, min_ms, max_ms, sum_ms, (int)received);
    close(sock_fd);
    return received > 0 ? 0 : 1;
}

int main(int argc, char **argv)
{
    char host[256] = "";
    char num[32];
    char buf[32];
    int port = 0;
    int count = 0;
    int timeout_ms = DEFAULT_TIMEOUT_MS;
    int have_host = 0;
    int i;
    int rc;

    setvbuf(stdout, NULL, _IONBF, 0);

    for (i = 1; i < argc; i++) {
        if (strcmp(argv[i], "-d") == 0) {
            g_debug = 1;
        } else if (strcmp(argv[i], "-n") == 0 && i + 1 < argc) {
            count = atoi(argv[++i]);
        } else if (strcmp(argv[i], "-t") == 0 && i + 1 < argc) {
            timeout_ms = atoi(argv[++i]);
        } else if (!have_host) {
            snprintf(host, sizeof(host), "%s", argv[i]);
            have_host = 1;
        } else if (port == 0) {
            port = atoi(argv[i]);
        }
    }

    if (!have_host || port == 0) {
        if (argc > 1) {
            printf("usage: udp_pinger_client <host> <port> [-n count] [-t timeout_ms] [-d]\n");
            pause_exit(1);
        }
        // запуск двойным кликом, параметры спрашиваем в консоли
        printf("UDP pinger client (lab 13)\n\n");
        ask("Server host", "127.0.0.1", host, sizeof(host));
        snprintf(num, sizeof(num), "%d", DEFAULT_PORT);
        ask("Server port", num, buf, sizeof(buf));
        port = atoi(buf);
        snprintf(num, sizeof(num), "%d", DEFAULT_COUNT);
        ask("How many pings", num, buf, sizeof(buf));
        count = atoi(buf);
        ask("Timeout, ms", "1000", num, sizeof(num));
        timeout_ms = atoi(num);
        ask("Debug output on, 1 or 0", "0", num, sizeof(num));
        g_debug = atoi(num);
    }

    if (count <= 0) {
        count = DEFAULT_COUNT;
    }
    if (timeout_ms <= 0) {
        timeout_ms = DEFAULT_TIMEOUT_MS;
    }

    rc = run_client(host, port, count, timeout_ms);
    if (argc < 2 || rc != 0) {
        pause_exit(rc);
    }
    return rc;
}
