@echo off
webproxy.exe %*
echo.
echo Done. Press any key...
pause >nul
