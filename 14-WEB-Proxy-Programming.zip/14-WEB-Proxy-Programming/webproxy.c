// Лабораторная работа №14, HTTP прокси с кэшем на диске
// доп кредит: поток на каждого клиента

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <strings.h>
#include <unistd.h>
#include <pthread.h>
#include <time.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <sys/stat.h>
#include <sys/time.h>
#include <netinet/in.h>
#include <netdb.h>
#include <dirent.h>
#include <arpa/inet.h>

#define BUF_SIZE 8192
#define MAX_OBJECT (BUF_SIZE * 1024)
#define CACHE_DIR "cache"
#define DEFAULT_PORT 8888

static int g_port = DEFAULT_PORT;
static char g_cache_dir[256] = CACHE_DIR;

static long g_requests = 0;
static long g_hits = 0;
static long g_misses = 0;
static long g_errors = 0;

static pthread_mutex_t g_stats_mutex = PTHREAD_MUTEX_INITIALIZER;
static pthread_mutex_t g_cache_mutex = PTHREAD_MUTEX_INITIALIZER;

static void log_line(const char *text)
{
    char stamp[32];
    time_t now = time(NULL);
    struct tm *tm = localtime(&now);

    strftime(stamp, sizeof(stamp), "%H:%M:%S", tm);
    printf("[%s] %s\n", stamp, text);
    fflush(stdout);
}

static void count(long *field)
{
    pthread_mutex_lock(&g_stats_mutex);
    (*field)++;
    pthread_mutex_unlock(&g_stats_mutex);
}

static void print_stats(void)
{
    long req, hits, misses, errs;

    pthread_mutex_lock(&g_stats_mutex);
    req = g_requests;
    hits = g_hits;
    misses = g_misses;
    errs = g_errors;
    pthread_mutex_unlock(&g_stats_mutex);

    printf("\n--- proxy statistics ---\n");
    printf("requests %ld, cache hits %ld, cache misses %ld, errors %ld\n", req, hits, misses, errs);
    if (req > 0) {
        printf("hit rate %d%%\n", (int)(hits * 100 / req));
    }
    fflush(stdout);
}

// поиск подстроки без учёта регистра, свой, чтобы не зависеть от glibc
static char *find_ci(const char *hay, const char *needle)
{
    size_t nlen = strlen(needle);
    const char *p;

    if (nlen == 0) {
        return (char *)hay;
    }
    for (p = hay; *p; p++) {
        if (strncasecmp(p, needle, nlen) == 0) {
            return (char *)p;
        }
    }
    return NULL;
}

// имя файла в кэше получается из url хэшем, чтобы не было мусора в именах
static void cache_name(const char *url, char *out, int out_size)
{
    unsigned long h = 2166136261u;
    const char *p;

    for (p = url; *p; p++) {
        h ^= (unsigned char)*p;
        h *= 16777619u;
    }
    snprintf(out, out_size, "%s/%08lx.cache", g_cache_dir, h & 0xffffffffu);
}

// в файле кэша первая строка - url, потом сразу ответ
static int cache_read(const char *url, char *data, int max)
{
    char name[600];
    char first[1200] = "";
    FILE *f;
    int n;

    cache_name(url, name, sizeof(name));
    f = fopen(name, "rb");
    if (f == NULL) {
        return 0;
    }
    if (fgets(first, sizeof(first), f) == NULL) {
        fclose(f);
        return 0;
    }
    first[strcspn(first, "\r\n")] = '\0';
    if (strcmp(first, url) != 0) {
        // хэш совпал у разных url, такой файл удаляю
        fclose(f);
        remove(name);
        return 0;
    }
    n = (int)fread(data, 1, (size_t)max, f);
    fclose(f);
    return n;
}

static void cache_write(const char *url, const char *data, int len)
{
    char name[600];
    char tmp[620];
    FILE *f;

    cache_name(url, name, sizeof(name));
    snprintf(tmp, sizeof(tmp), "%s.tmp", name);
    f = fopen(tmp, "wb");
    if (f == NULL) {
        return;
    }
    fprintf(f, "%s\n", url);
    fwrite(data, 1, (size_t)len, f);
    fclose(f);
    rename(tmp, name);
}

static void cache_clear(void)
{
    DIR *dir = opendir(g_cache_dir);
    struct dirent *de;
    int removed = 0;

    if (dir == NULL) {
        printf("cache dir %s is empty\n", g_cache_dir);
        return;
    }
    while ((de = readdir(dir)) != NULL) {
        size_t len = strlen(de->d_name);
        int is_cache = (len > 6 && strcmp(de->d_name + len - 6, ".cache") == 0);
        int is_tmp = (len > 4 && strcmp(de->d_name + len - 4, ".tmp") == 0);

        if (is_cache || is_tmp) {
            char full[700];

            snprintf(full, sizeof(full), "%s/%s", g_cache_dir, de->d_name);
            if (remove(full) == 0 && is_cache) {
                removed++;
            }
        }
    }
    closedir(dir);
    printf("cache cleared, removed %d objects\n", removed);
}

static void cache_count(void)
{
    DIR *dir = opendir(g_cache_dir);
    struct dirent *de;
    int count = 0;

    if (dir == NULL) {
        printf("cache is empty\n");
        return;
    }
    while ((de = readdir(dir)) != NULL) {
        size_t len = strlen(de->d_name);

        if (len > 6 && strcmp(de->d_name + len - 6, ".cache") == 0) {
            count++;
        }
    }
    closedir(dir);
    printf("cache objects: %d\n", count);
}

// разбираю ссылку на host, port и path, все три формы запроса
static int parse_url(const char *url, char *host, int host_size, char *path, int path_size,
                     int *port)
{
    char work[1200];
    char path_copy[1200];
    const char *start;
    char *slash;

    snprintf(work, sizeof(work), "%s", url);
    start = work;
    if (strncasecmp(start, "http://", 7) == 0) {
        start += 7;
    }
    slash = strchr(start, '/');
    if (slash != NULL) {
        // путь сохраняю до того, как разрежу строку на host и path
        snprintf(path_copy, sizeof(path_copy), "%s", slash);
        *slash = '\0';
    } else {
        snprintf(path_copy, sizeof(path_copy), "/");
    }
    if (start[0] == '\0') {
        return 0;
    }
    *port = 80;
    {
        char *colon = strrchr(start, ':');
        if (colon != NULL) {
            *colon = '\0';
            *port = atoi(colon + 1);
        }
    }
    if (start[0] == '\0' || *port <= 0 || *port > 65535) {
        return 0;
    }
    snprintf(host, host_size, "%s", start);
    snprintf(path, path_size, "%s", path_copy);
    return 1;
}

// хост из заголовка Host: в запросе
static int host_from_header(const char *request, char *host, int host_size, char *path,
                            int path_size, int *port)
{
    char *h = find_ci(request, "Host:");
    char *line_end;
    int len;
    char *colon;

    if (h == NULL) {
        return 0;
    }
    line_end = strstr(h, "\r\n");
    if (line_end == NULL) {
        return 0;
    }
    h += 5;
    while (*h == ' ' || *h == '\t') {
        h++;
    }
    len = (int)(line_end - h);
    if (len <= 0 || len >= host_size) {
        return 0;
    }
    memcpy(host, h, (size_t)len);
    host[len] = '\0';
    *port = 80;
    colon = strrchr(host, ':');
    if (colon != NULL) {
        *colon = '\0';
        *port = atoi(colon + 1);
    }
    if (path[0] == '\0') {
        snprintf(path, path_size, "/");
    }
    return 1;
}

static int write_all(int fd, const char *data, int len)
{
    int done = 0;

    while (done < len) {
        int n = (int)send(fd, data + done, (size_t)(len - done), 0);

        if (n <= 0) {
            return -1;
        }
        done += n;
    }
    return done;
}

// запрос к настоящему серверу, ответ целиком в buf
static int fetch(const char *host, int port, const char *path, char *buf, int max)
{
    struct addrinfo hints, *res = NULL;
    struct timeval tv;
    char port_str[16];
    char req[2048];
    int fd;
    int total = 0;
    int rc = -1;

    memset(&hints, 0, sizeof(hints));
    hints.ai_family = AF_INET;
    hints.ai_socktype = SOCK_STREAM;
    snprintf(port_str, sizeof(port_str), "%d", port);
    if (getaddrinfo(host, port_str, &hints, &res) != 0) {
        printf("  cannot resolve %s\n", host);
        return -1;
    }
    fd = socket(AF_INET, SOCK_STREAM, 0);
    if (fd < 0) {
        freeaddrinfo(res);
        return -1;
    }
    tv.tv_sec = 10;
    tv.tv_usec = 0;
    setsockopt(fd, SOL_SOCKET, SO_RCVTIMEO, &tv, sizeof(tv));
    setsockopt(fd, SOL_SOCKET, SO_SNDTIMEO, &tv, sizeof(tv));
    if (connect(fd, res->ai_addr, res->ai_addrlen) < 0) {
        freeaddrinfo(res);
        close(fd);
        printf("  cannot connect to %s:%d\n", host, port);
        return -1;
    }
    freeaddrinfo(res);

    snprintf(req, sizeof(req),
             "GET %s HTTP/1.0\r\nHost: %s\r\nUser-Agent: webproxy-lab14\r\n"
             "Connection: close\r\n\r\n", path, host);
    if (write_all(fd, req, (int)strlen(req)) < 0) {
        close(fd);
        return -1;
    }

    for (;;) {
        int n = (int)recv(fd, buf + total, (size_t)(max - total), 0);

        if (n <= 0) {
            break;
        }
        total += n;
        if (total >= max - 1) {
            break;
        }
    }
    close(fd);
    if (total > 0) {
        buf[total] = '\0';
        rc = total;
    }
    return rc;
}

// в кэш кладу только успешный ответ, который сам себя не запрещает хранить
static int can_cache(const char *response)
{
    int code = 0;

    if (sscanf(response, "HTTP/%*d.%*d %d", &code) != 1) {
        return 0;
    }
    if (code != 200) {
        return 0;
    }
    if (find_ci(response, "Cache-Control: no-store") != NULL) {
        return 0;
    }
    if (find_ci(response, "Cache-Control: no-cache") != NULL) {
        return 0;
    }
    return 1;
}

static void send_text(int fd, const char *status, const char *text)
{
    char buf[512];

    snprintf(buf, sizeof(buf), "HTTP/1.0 %s\r\nContent-Type: text/plain\r\n"
             "Content-Length: %d\r\n\r\n%s", status, (int)strlen(text), text);
    write_all(fd, buf, (int)strlen(buf));
}

static void handle_request(char *request, int client_fd, const char *addr)
{
    char method[16] = "";
    char url[1024] = "";
    char version[32] = "";
    char host[300] = "";
    char path[1200] = "";
    char note[2200];
    int port = 80;
    char *buf;
    int n;
    int ok;

    if (sscanf(request, "%15s %1023s %31s", method, url, version) != 3) {
        send_text(client_fd, "400 Bad Request", "Bad request\n");
        return;
    }
    count(&g_requests);

    // три формы запроса:
    // 1) браузер с прокси: GET http://host/path HTTP/1.0
    // 2) строка в браузере: GET /http://host/path HTTP/1.0
    // 3) обычный запрос с заголовком Host: GET /path HTTP/1.0
    if (strncasecmp(url, "http://", 7) == 0) {
        ok = parse_url(url, host, sizeof(host), path, sizeof(path), &port);
    } else if (strncmp(url, "/http://", 8) == 0) {
        ok = parse_url(url + 1, host, sizeof(host), path, sizeof(path), &port);
    } else {
        ok = host_from_header(request, host, sizeof(host), path, sizeof(path), &port);
        if (ok) {
            snprintf(path, sizeof(path), "%s", url);
        }
    }
    if (!ok) {
        snprintf(note, sizeof(note), "%s %s -> 400, no host in request", addr, url);
        log_line(note);
        count(&g_errors);
        send_text(client_fd, "400 Bad Request", "Need a full URL or a Host header\n");
        return;
    }
    snprintf(note, sizeof(note), "%s %s %s:%d%s", addr, method, host, port, path);
    log_line(note);

    if (strcmp(method, "GET") != 0) {
        count(&g_errors);
        send_text(client_fd, "405 Method Not Allowed", "Only GET is supported\n");
        return;
    }

    buf = malloc(MAX_OBJECT);
    if (buf == NULL) {
        count(&g_errors);
        send_text(client_fd, "500 Internal Server Error", "Out of memory\n");
        return;
    }

    pthread_mutex_lock(&g_cache_mutex);
    n = cache_read(url, buf, MAX_OBJECT - 1);
    pthread_mutex_unlock(&g_cache_mutex);

    if (n > 0) {
        count(&g_hits);
        snprintf(note, sizeof(note), "%s %s -> cache hit, %d bytes", addr, url, n);
        log_line(note);
        write_all(client_fd, buf, n);
    } else {
        count(&g_misses);
        snprintf(note, sizeof(note), "%s %s -> cache miss", addr, url);
        log_line(note);

        n = fetch(host, port, path, buf, MAX_OBJECT - 1);
        if (n <= 0) {
            count(&g_errors);
            snprintf(note, sizeof(note), "%s %s -> 502, server not reachable", addr, url);
            log_line(note);
            send_text(client_fd, "502 Bad Gateway", "Cannot reach the server\n");
        } else {
            int stored = can_cache(buf);
            int code = 0;

            sscanf(buf, "HTTP/%*d.%*d %d", &code);
            snprintf(note, sizeof(note), "%s %s -> %d from server, %d bytes, %s",
                     addr, url, code, n, stored ? "stored in cache" : "not cached");
            log_line(note);
            if (stored) {
                pthread_mutex_lock(&g_cache_mutex);
                cache_write(url, buf, n);
                pthread_mutex_unlock(&g_cache_mutex);
            }
            write_all(client_fd, buf, n);
        }
    }

    free(buf);
}

struct client_arg {
    int fd;
    char addr[64];
};

static void *client_thread(void *arg)
{
    struct client_arg *a = (struct client_arg *)arg;
    char *req = malloc(BUF_SIZE * 2);
    int len = 0;

    if (req != NULL) {
        while (len < BUF_SIZE * 2 - 1) {
            int n = (int)recv(a->fd, req + len, (size_t)(BUF_SIZE * 2 - len - 1), 0);

            if (n <= 0) {
                break;
            }
            len += n;
            req[len] = '\0';
            if (strstr(req, "\r\n\r\n") != NULL) {
                break;
            }
        }
        if (len > 0) {
            handle_request(req, a->fd, a->addr);
        }
        free(req);
    }
    close(a->fd);
    free(a);
    return NULL;
}

static int run_proxy(void)
{
    struct sockaddr_in addr;
    int listen_fd;

    mkdir(g_cache_dir, 0755);
    listen_fd = socket(AF_INET, SOCK_STREAM, 0);
    if (listen_fd < 0) {
        printf("cannot create socket\n");
        return 1;
    }
    {
        int yes = 1;
        setsockopt(listen_fd, SOL_SOCKET, SO_REUSEADDR, &yes, sizeof(yes));
    }
    memset(&addr, 0, sizeof(addr));
    addr.sin_family = AF_INET;
    addr.sin_addr.s_addr = htonl(INADDR_ANY);
    addr.sin_port = htons((unsigned short)g_port);
    if (bind(listen_fd, (struct sockaddr *)&addr, sizeof(addr)) < 0) {
        printf("cannot bind to port %d, is it busy?\n", g_port);
        close(listen_fd);
        return 1;
    }
    listen(listen_fd, 32);

    printf("HTTP proxy with cache, lab 14\n");
    printf("listening on port %d, cache dir %s\n", g_port, g_cache_dir);
    printf("open http://127.0.0.1:%d/http://example.com/ in a browser, or set proxy\n\n", g_port);

    for (;;) {
        struct sockaddr_in peer;
        socklen_t peer_len = sizeof(peer);
        int fd = accept(listen_fd, (struct sockaddr *)&peer, &peer_len);
        struct client_arg *arg;
        pthread_t th;
        pthread_attr_t attr;

        if (fd < 0) {
            continue;
        }
        arg = malloc(sizeof(*arg));
        if (arg == NULL) {
            close(fd);
            continue;
        }
        arg->fd = fd;
        inet_ntop(AF_INET, &peer.sin_addr, arg->addr, sizeof(arg->addr));

        pthread_attr_init(&attr);
        pthread_attr_setdetachstate(&attr, PTHREAD_CREATE_DETACHED);
        pthread_attr_setstacksize(&attr, 512 * 1024);
        if (pthread_create(&th, &attr, client_thread, arg) != 0) {
            printf("cannot create thread, serving in the main thread\n");
            client_thread(arg);
        }
        pthread_attr_destroy(&attr);

        print_stats();
    }

    close(listen_fd);
    return 0;
}

static void pause_exit(int rc)
{
    printf("\nPress Enter to exit...");
    (void)getchar();
    exit(rc);
}

static void ask(const char *prompt, const char *def, char *buf, int size)
{
    char *p;

    printf("%s [%s]: ", prompt, def);
    fflush(stdout);
    if (fgets(buf, size, stdin) == NULL) {
        snprintf(buf, size, "%s", def);
        return;
    }
    buf[strcspn(buf, "\r\n")] = '\0';
    p = buf;
    while (*p == ' ' || *p == '\t') {
        p++;
    }
    if (*p == '\0') {
        snprintf(buf, size, "%s", def);
    } else if (p != buf) {
        memmove(buf, p, strlen(p) + 1);
    }
}

int main(int argc, char **argv)
{
    char buf[256];
    int have_args = 0;
    int clear = 0;
    int count_only = 0;
    int i;

    setvbuf(stdout, NULL, _IONBF, 0);

    for (i = 1; i < argc; i++) {
        if (strcmp(argv[i], "-p") == 0 && i + 1 < argc) {
            g_port = atoi(argv[++i]);
            have_args = 1;
        } else if (strcmp(argv[i], "-clear") == 0) {
            clear = 1;
        } else if (strcmp(argv[i], "-count") == 0) {
            count_only = 1;
        } else if (argv[i][0] != '-') {
            g_port = atoi(argv[i]);
            have_args = 1;
        }
    }

    mkdir(g_cache_dir, 0755);
    if (clear) {
        cache_clear();
        return 0;
    }
    if (count_only) {
        cache_count();
        return 0;
    }

    if (!have_args) {
        if (argc > 1) {
            printf("usage: webproxy <port> | -clear | -count\n");
            pause_exit(1);
        }
        // запуск двойным кликом, параметры спрашиваем в консоли
        printf("HTTP proxy (lab 14)\n\n");
        ask("Port to listen", "8888", buf, sizeof(buf));
        g_port = atoi(buf);
    }
    if (g_port <= 0 || g_port > 65535) {
        printf("bad port %d\n", g_port);
        pause_exit(1);
    }

    return run_proxy();
}
